/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ModuleData } from "../types";

export const modulesData: ModuleData[] = [
  {
    id: "waterfall",
    title: "1. Waterfall Model",
    shortDescription: "Rigid, sequential, and disciplined. Complete each phase 100% before moving forward.",
    emoji: "🌊",
    academicContext: "The Waterfall model is the grandfather of software process models, first described by Winston Royce in 1970. It treats software development as a linear, downward flow where each stage must be fully completed, documented, and signed off before the next can begin. It is highly document-driven and provides extreme structural predictability.",
    detailedContent: [
      {
        sectionTitle: "Core Philosophy & Sequential Stages",
        paragraphs: [
          "Waterfall is a non-iterative design process. It consists of fixed, sequential phases: Requirements Analysis (where all specifications are locked), System Design (architecting the blueprint), Implementation (the actual typing of code), Integration & Testing (assembling and verifying the entire application), Deployment (releasing to users), and Maintenance.",
          "Because feedback loops are highly restricted, any error made in the Requirements phase that is not discovered until Testing can require massive, expensive structural rewrites. Waterfall treats requirements as immutable constants."
        ]
      },
      {
        sectionTitle: "★ Case Study: NASA Space Shuttle Avionics Software",
        paragraphs: [
          "In the 1980s, NASA's Space Shuttle program required flight computer software with zero-fault tolerance. A single bug could destroy a multi-billion dollar shuttle and cost human lives. NASA used a strict, ultra-disciplined Waterfall process.",
          "NASA's Primary Avionics Software System (PASS) was built with up-front requirements that were verified through hundreds of pages of mathematical proofs. Coding did not start until years of design were completed. Testing matched the exact specs step-by-step. The result? Out of tens of millions of lines of code across dozens of missions, only a handful of minor anomalies ever occurred in flight. This proves Waterfall is unmatched when safety is absolute and requirements are mathematically fixed."
        ]
      },
      {
        sectionTitle: "Ideal Conditions & Fatal Pitfalls",
        paragraphs: [
          "Waterfall is ideal when: Requirements are well-understood and highly stable, the technology stack is mature, the team is experienced, and safety is critical (e.g., medical pacemakers, rocket systems).",
          "It is fatal when: Building startup products, competitive consumer web apps, or any system where the client cannot foresee exactly how the application should work up-front. Users rarely know what they need until they see a working model, which Waterfall does not provide until the very end."
        ]
      }
    ],
    relatableExamples: [
      {
        title: "Building a Concrete Suspension Bridge",
        scenario: "You are hired by the government to build a bridge across a major river. You cannot pour concrete for the pillars while still deciding how many lanes the bridge will have, nor can you alter the span width mid-construction.",
        analogy: "Waterfall is like printing a physical dictionary: once the ink is dry and the pages are bound, editing a typo on page 84 requires scrapping and reprinting the entire book.",
        takeaway: "Use Waterfall when the cost of changing requirements later is higher than the cost of massive up-front planning."
      }
    ],
    quiz: [
      {
        id: "wf_q1",
        question: "Why is an error in the Requirements phase so expensive to fix in a Waterfall model?",
        options: [
          "The client charges late fees for altering requirements.",
          "Because Waterfall does not support code editors, requiring developers to write raw machine binaries.",
          "An early error cascades down, meaning designs, code, and test cases must all be dismantled and rebuilt.",
          "Database servers charge higher storage costs for older specifications."
        ],
        correctAnswer: 2,
        explanation: "Since Waterfall is strictly linear, an error at the start means all downstream blueprints, implementations, and test cases are built on flawed premises and must be fully refactored."
      },
      {
        id: "wf_q2",
        question: "For which project would the Waterfall model be MOST appropriate?",
        options: [
          "A fast-paced social media app where features are added based on viral trends.",
          "An embedded pacemaker firmware controller that must operate safely for 15 years with zero updates.",
          "A corporate web homepage whose layout changes based on monthly marketing feedback.",
          "A modern online multiplayer video game with weekly updates."
        ],
        correctAnswer: 1,
        explanation: "The pacemaker firmware is a safety-critical device with highly predictable, stable requirements where failure is life-threatening, making Waterfall's rigid verification ideal."
      }
    ],
    keyTakeaways: [
      "Requirements are frozen early; changes are treated as expensive anomalies.",
      "Extensive documentation at every phase ensures the project can survive staff turnover.",
      "Working software is only delivered at the very end of the lifecycle."
    ]
  },
  {
    id: "incremental",
    title: "2. Incremental Model",
    shortDescription: "Divide and conquer. Build a basic core first, then add features in sequential releases.",
    emoji: "🪜",
    academicContext: "The Incremental model breaks the system down into small, manageable chunks called 'increments.' Each increment is developed using a mini-waterfall process (Requirements, Design, Code, Test, Deploy). The first increment always delivers the 'Core Product,' and subsequent increments gradually overlay supplementary features.",
    detailedContent: [
      {
        sectionTitle: "Phased Feature Overlay Mechanics",
        paragraphs: [
          "Instead of trying to launch a giant, complex system all at once, the Incremental model delivers early value. In Increment 1, you build the minimum viable core (e.g., database connection and basic user accounts). In Increment 2, you add the payment engine. In Increment 3, you introduce analytics.",
          "This reduces initial delivery risks, allows the client to gain confidence, and provides a continuous stream of usable software while developers work on downstream modules."
        ]
      },
      {
        sectionTitle: "★ Case Study: Microsoft Word Evolution",
        paragraphs: [
          "When Microsoft originally engineered Microsoft Word, they did not attempt to build modern complex formatting, cloud collaboration, spelling grammar checkers, and PDF exporting in their first version. They used an incremental strategy.",
          "Increment 1 delivered a basic text editor that could load, type, and save plain text files. Once that was stable in the marketplace, Increment 2 introduced basic rich-text formatting (bold, italics, fonts). Increment 3 added spellcheck, and decades later, cloud storage integration was layered in. By modularizing the release pipeline, Microsoft stayed dominant without collapsing under the weight of feature bloat."
        ]
      },
      {
        sectionTitle: "Pros, Cons & Integration Challenges",
        paragraphs: [
          "The major advantage of the Incremental model is early revenue generation and fast deployment of the core system, alongside easier feedback routing between releases.",
          "However, the fundamental challenge is system architecture. The lead architect must design a highly modular, open-ended skeleton from Day 1. If the core skeleton is poorly designed, trying to append new increments later will cause structural cracks, regression bugs, and modular mismatch."
        ]
      }
    ],
    relatableExamples: [
      {
        title: "Constructing a Suburban Housing Development",
        scenario: "Instead of building 500 houses simultaneously and leaving buyers waiting for 5 years, the developer builds Phase 1 (50 houses, roads, utility core) so families can move in immediately, then builds Phase 2 and 3 around them.",
        analogy: "Incremental is like painting a masterpiece by first sketching the outline (core), then painting the background, then adding the characters, rather than trying to paint every pixel in one pass from top to bottom.",
        takeaway: "Get the core working first. A functioning simple system is infinitely more valuable than a broken complex system."
      }
    ],
    quiz: [
      {
        id: "inc_q1",
        question: "What is always delivered by the FIRST increment of an Incremental process?",
        options: [
          "The complete polished final user manual.",
          "The Core Product containing the absolute essential operations of the system.",
          "A disposable throwaway mock screen with fake data.",
          "An automatic backup recovery cluster."
        ],
        correctAnswer: 1,
        explanation: "The first increment focuses strictly on delivering the core utility of the software, enabling users to perform baseline operations immediately while secondary features wait."
      },
      {
        id: "inc_q2",
        question: "What is the primary technical risk associated with the Incremental model?",
        options: [
          "Users might refuse to pay for updates.",
          "The code compiled for Increment 1 becomes corrupted over time.",
          "Poor initial system architecture can make appending subsequent increments extremely difficult, causing regression bugs.",
          "The linter cannot analyze multi-increment code repos."
        ],
        correctAnswer: 2,
        explanation: "If the initial architectural skeleton is not built to be modular and open-ended, force-fitting new feature modules in later increments will break the existing code."
      }
    ],
    keyTakeaways: [
      "Splits development into successive, functional, deployable versions.",
      "Delivers rapid value to stakeholders, lowering initial funding barriers.",
      "Requires a masterfully designed modular architectural backbone."
    ]
  },
  {
    id: "prototype",
    title: "3. Prototype Model",
    shortDescription: "Build a mock quick-and-dirty model to discover what the client actually wants.",
    emoji: "🎨",
    academicContext: "The Prototype model is a 'learning-first' software process. It is applied when the client has a vague idea of what they want but cannot specify formal requirements. The development team rapidly builds a simplified, interactive mockup (a prototype) to show the client, gathers feedback, refines the prototype, and only writes production code once requirements are crystal clear.",
    detailedContent: [
      {
        sectionTitle: "The Iterative Prototype Refining Loop",
        paragraphs: [
          "The process begins with Quick Planning, followed by Quick Design. A prototype is built rapidly, focusing on user-facing visual interfaces while ignoring back-end database architecture, error handling, or security protocols. This prototype is evaluated by the client, generating feedback.",
          "The team refines the mockup based on this feedback in multiple iterations. Once the client says, 'Yes! This is exactly what I mean!' the prototype has served its purpose. It is usually discarded, and formal production software is engineered from the ground up using the discovered requirements."
        ]
      },
      {
        sectionTitle: "★ Case Study: Jeff Hawkins and the Palm Pilot Wooden Block",
        paragraphs: [
          "In the mid-1990s, Jeff Hawkins was designing a brand-new pocket computer, the Palm Pilot. Handheld computing had failed in the market before, and nobody knew what features users would actually utilize on a tiny touch-screen.",
          "Instead of spending millions writing complex mobile kernels, Hawkins carved a block of wood to the exact size of the proposed device, cut out a paper sheet representing the screen, and walked around with it in his pocket for weeks. When people asked for the time or calendar, he tapped the wood with a small stick. This 'mockup prototype' taught him that pocket-size and instant-on search were critical, while complex typing was a waste. The resulting product revolutionized the tech industry, built entirely from a zero-code physical prototype."
        ]
      },
      {
        sectionTitle: "The Danger of Prototype Creep",
        paragraphs: [
          "While prototyping drastically reduces requirements errors, it carries a severe psychological trap: 'Prototype Creep.'",
          "When clients see a gorgeous, clickable UI prototype, they assume the system is 90% finished. They pressure the developers: 'Just deploy this mockup to production!' If the team gives in and builds on top of the quick-and-dirty prototype code, they inherit an unstable system with no security, poor SQL schemas, and zero unit tests."
        ]
      }
    ],
    relatableExamples: [
      {
        title: "Clay Modeling in Automotive Design",
        scenario: "Before spending $200 million tooling a factory to stamp steel panels for a new sports car, designers sculpt a full-scale model out of clay to evaluate aerodynamics, shape, and visual appeal in real light.",
        analogy: "Prototyping is like sketching a draft of a portrait with a pencil and eraser, allowing you to easily adjust the smile before committing to permanent oil paints.",
        takeaway: "Build to learn. Do not confuse a clickable illusion with engineered software."
      }
    ],
    quiz: [
      {
        id: "pr_q1",
        question: "What is the primary purpose of building a prototype in this model?",
        options: [
          "To deliver the final software ahead of schedule to save money.",
          "To clarify and discover stable requirements by giving the user a tangible, visual model to evaluate.",
          "To test the capacity limit of the production database cluster.",
          "To train junior developers on simple coding techniques before writing real code."
        ],
        correctAnswer: 1,
        explanation: "Prototyping's entire value is cognitive: it allows non-technical users to interact with a visual mockup and realize what they actually need, transforming vague ideas into concrete specs."
      },
      {
        id: "pr_q2",
        question: "What is 'Prototype Creep' (the psychological trap of prototyping)?",
        options: [
          "The prototype code gradually eating up all the server's hard drive space.",
          "Junior developers adding hidden joke features to the user interface.",
          "Stakeholders seeing a polished visual interface and pressuring developers to deploy the fragile, mock-up code directly into production.",
          "The UI mockup changing its theme automatically in dark mode."
        ],
        correctAnswer: 2,
        explanation: "Because a prototype looks finished on the outside, non-technical managers and clients often demand that the mock-up be deployed immediately, unaware that there is no real, secure engine behind it."
      }
    ],
    keyTakeaways: [
      "Prototypes are quick-and-dirty tools meant to explore requirements, not run production load.",
      "Most professional prototypes should be discarded; keeping them leads to fragile architecture.",
      "Drastically reduces the risk of building an application that users reject."
    ]
  },
  {
    id: "vmodel",
    title: "4. V-Model (Verification & Validation)",
    shortDescription: "Symmetrical precision. For every phase of development, there is an equal phase of testing.",
    emoji: "✌️",
    academicContext: "The V-Model is an extension of the Waterfall model that curves upwards to form a 'V' shape. It emphasizes a strict, symmetrical relationship between development phases (the left side of the V) and verification/validation testing phases (the right side of the V). Testing is not an afterthought; it is planned in parallel with every design document.",
    detailedContent: [
      {
        sectionTitle: "Symmetrical Mapping of Specs to Tests",
        paragraphs: [
          "The left leg of the V descends from Business Requirements, to System Specs, to Architecture Design, down to Unit Coding. The right leg of the V ascends from Unit Testing, to Integration Testing, to System Testing, up to User Acceptance Testing.",
          "Crucially, the horizontal links of the V represent planning. When you write the 'System Specification Document' on the left, you write the 'System Test Plan' for the right at the exact same time. This ensures that every line of design is immediately verifiable."
        ]
      },
      {
        sectionTitle: "★ Case Study: Airbus Fly-By-Wire Flight Systems",
        paragraphs: [
          "Commercial airplanes like the Airbus A320 use 'Fly-By-Wire' systems where pilot control inputs are read by computers, computed against aerodynamics safety constraints, and sent to hydraulic actuators.",
          "Airbus uses a strict V-Model. When the System Engineers specify 'Slat/Flap limiting speeds', the Test Engineers simultaneously design the Acceptance Test scripts to simulate overspeed inputs in flight simulators. Coding the flight software only begins after the specs and tests are perfectly mapped. If a programmer writes a module, it is immediately unit-tested against the module spec, integrated and checked against the architectural spec, and flight-tested against the system requirements. This rigid symmetry is why commercial aviation has become the safest transit system on Earth."
        ]
      },
      {
        sectionTitle: "When to Enforce the V-Model",
        paragraphs: [
          "The V-Model is highly superior to standard Waterfall because it forces testing to be planned early, catching design bugs before code is even written.",
          "It is mandatory for regulated industries: medical imaging, automotive safety standards (ISO 26262), defense systems, and financial ledger settlement. Its main drawback is that it remains rigid—if a business requirement changes at the top of the V, the entire symmetrical V structure must be updated."
        ]
      }
    ],
    relatableExamples: [
      {
        title: "Developing a Commercial Medical Ventilator",
        scenario: "When designing a lung ventilator, you can't just code a touch screen and plug it in. For every sensor specification (e.g., alert if pressure > 40 cmH2O), there must be a corresponding verification test designed to physically pump high pressure and assert that the alert triggers instantly.",
        analogy: "The V-Model is like a dual-column checklist: the left column lists all the parts we need to assemble a cabinet, and the right column lists the exact measurements to verify each part fits, keeping the construction completely aligned.",
        takeaway: "Testing is not something you do after you code; it is something you plan while you design."
      }
    ],
    quiz: [
      {
        id: "vm_q1",
        question: "In the V-Model, what is the horizontal relationship between the left leg and the right leg?",
        options: [
          "The left leg contains the code, and the right leg contains the database tables.",
          "For every development phase on the left, the corresponding test plan on the right is designed in parallel.",
          "The right leg is only executed if the left leg fails during deployment.",
          "There is no relationship; they are run by different companies."
        ],
        correctAnswer: 1,
        explanation: "The core innovation of the V-Model is parallel planning. When designing a specific tier of specification (e.g., System Spec), you write its corresponding testing checks (e.g., System Test Plan) at the same time."
      },
      {
        id: "vm_q2",
        question: "Which testing tier is directly mapped to the initial 'User Requirements' phase at the very top of the V-Model?",
        options: [
          "Unit Testing",
          "Integration Testing",
          "User Acceptance Testing (UAT)",
          "Compiler Syntax Checking"
        ],
        correctAnswer: 2,
        explanation: "User Acceptance Testing (UAT) sits at the top right of the V, verifying that the completed system successfully satisfies the initial business and user requirements defined at the top left."
      }
    ],
    keyTakeaways: [
      "Links development phases directly to corresponding testing levels.",
      "Forces test planning to occur early in the project lifecycle, saving huge costs.",
      "Extremely robust but highly rigid; expensive to alter mid-project."
    ]
  },
  {
    id: "spiral",
    title: "5. Spiral Model",
    shortDescription: "Risk-driven iterations. Loop repeatedly through evaluation, prototyping, and planning.",
    emoji: "🌀",
    academicContext: "The Spiral model, formulated by Barry Boehm in 1986, is a risk-driven evolutionary process model. It combines the structured nature of Waterfall with the iterative aspect of prototyping. Instead of a linear sequence, the project progresses in a spiral, where each loop represents an iteration focused on identifying, analyzing, and eliminating project risks.",
    detailedContent: [
      {
        sectionTitle: "The Four Quadrants of the Spiral",
        paragraphs: [
          "Every loop of the spiral progresses through four quadrants: 1. Determine Objectives, alternatives, and constraints. 2. Identify and Resolve Risks (where prototypes are built, benchmarks are run, and risk analysis is formalized). 3. Develop and Test (writing the software code for that loop). 4. Plan the Next Iteration.",
          "The radius of the spiral represents the cumulative budget and time spent, while the angular dimension represents progress made. With each spiral loop, the software grows into a more complete system as high-risk items are resolved."
        ]
      },
      {
        sectionTitle: "★ Case Study: US Navy DDG-1000 Zumwalt Destroyer Program",
        paragraphs: [
          "The US Navy's Zumwalt-class destroyer was engineered to be a stealth warship incorporating dozens of unproven, high-risk technologies: dual-band radar, an advanced induction motor, electric gun mounts, and a brand-new composite deckhouse.",
          "To manage this insane risk, the Navy used a Spiral model. Loop 1 focused purely on the radar risk: they built a mock radar array on a barge to test interference. Loop 2 tackled the power grid risk, assembling a land-based prototype engine. Loop 3 developed the software controls in small batches. If any loop revealed a critical failure, requirements were revised before proceeding. While extremely expensive, this risk-driven spiral prevented a catastrophic failure of the entire warship once hulls were constructed."
        ]
      },
      {
        sectionTitle: "The Risk-First Mental Pivot",
        paragraphs: [
          "The Spiral model is unique because it is entirely risk-driven. If your project has a risk that the database cannot handle 10,000 writes/sec, you do not write CSS or UI buttons. You spend Loop 1 building a database benchmark to resolve that risk.",
          "The major drawback is its complexity. It requires highly experienced risk analysts who can identify subtle technical, team, or market threats. It is also expensive, making it unsuitable for small, low-budget software projects."
        ]
      }
    ],
    relatableExamples: [
      {
        title: "Launching a Premium Theme Park",
        scenario: "Before spending $1 billion building a theme park, you first buy a small plot of land and build one roller-coaster to test soil stability and ticket pricing (Loop 1). Then, you build a small themed area to test crowd flows (Loop 2). Only then do you build the full grand park.",
        analogy: "The Spiral model is like navigating a thick, dark forest by taking 10 steps, stopping to check your map and listen for wild animals (risks), adjusting your compass, and taking the next 10 steps.",
        takeaway: "If you don't actively manage project risks, your risks will actively manage you."
      }
    ],
    quiz: [
      {
        id: "sp_q1",
        question: "What is the primary factor that drives the Spiral process model?",
        options: [
          "Completing coding as quickly as possible.",
          "Writing the largest amount of document proofs.",
          "Systematic Risk Analysis and Risk Management.",
          "Minimizing developer hourly rates."
        ],
        correctAnswer: 2,
        explanation: "The Spiral model is fundamentally a risk-driven model. Every loop is structured around identifying, analyzing, and mitigating the highest risks facing the project's success."
      },
      {
        id: "sp_q2",
        question: "What do the radius and the loops of the Spiral represent?",
        options: [
          "The radius represents the speed of the server, and the loops represent code files.",
          "The radius represents cumulative cost/time spent, and each loop represents a complete progress iteration.",
          "The radius is the size of the database, and the loops are security scans.",
          "The radius represents the number of users, and the loops represent features."
        ],
        correctAnswer: 1,
        explanation: "As the spiral winds outward, the radius increases, signifying the cumulative budget and schedule spent, while each circular rotation represents a full quadrant iteration."
      }
    ],
    keyTakeaways: [
      "Combines the systematic planning of Waterfall with iterative prototyping.",
      "Excellent for massive, complex, high-risk systems.",
      "Highly expensive and requires rare, specialized risk-assessment expertise."
    ]
  },
  {
    id: "rapid",
    title: "6. Rapid Application Development (RAD)",
    shortDescription: "High-speed construction. Use component reuse, CASE tools, and rapid prototyping to build apps in 60-90 days.",
    emoji: "⚡",
    academicContext: "Rapid Application Development (RAD) is a high-speed development model that emerged in the early 1990s as a response to the slow, heavy documentation of Waterfall. It focuses on rapid prototyping, user-driven JAD (Joint Application Design) workshops, and heavy component reusability to deliver fully functional systems within tight, time-boxed intervals of 60 to 90 days.",
    detailedContent: [
      {
        sectionTitle: "The RAD Lifecycle & Component Assembly",
        paragraphs: [
          "RAD consists of four phases: Requirements Planning (quick and high-level), User Design (where real users work directly with developers in JAD sessions to model the screens), Construction (rapid code generation, compiling, database creation, and component reuse), and Cutover (training and deployment).",
          "RAD heavily relies on Computer-Aided Software Engineering (CASE) tools, visual builders, and pre-existing library components. Instead of coding an authentication system from scratch, a RAD team plugs in an existing OAuth library, saving weeks of labor."
        ]
      },
      {
        sectionTitle: "★ Case Study: NYSE Trade Audit Compliance System",
        paragraphs: [
          "In the late 1990s, the New York Stock Exchange (NYSE) faced sudden regulatory pressure to track and audit fast-moving options trades to detect insider trading. They had a window of just 3 months to build and deploy a complex data-ingestion portal, or face massive federal fines.",
          "A classic Waterfall approach would have spent 3 months just on spec documents. Instead, they used a RAD strategy. They set up JAD workshops where regulatory compliance officers and database engineers sat in the same room. Using visual CASE builders, they mocked up screens live during meetings. They reused massive ingestion components from existing stock data systems. The system was fully built, integrated, tested, and cut over to production in exactly 82 days, proving RAD's power under severe timeline constraints."
        ]
      },
      {
        sectionTitle: "The Requirements of RAD & Its Severe Limits",
        paragraphs: [
          "RAD works miracles if: You have high-quality pre-built component libraries, a highly skilled team of rapid developers, and clients who can commit to intensive, daily JAD workshops.",
          "It fails terribly if: The system requires deep, custom algorithmic innovation (which can't be dragging-and-dropping), or if the team lacks existing libraries. Additionally, if users cannot commit to daily feedback sessions, the construction phase grinds to a halt."
        ]
      }
    ],
    relatableExamples: [
      {
        title: "Assembling a Modular Prefab Cabin",
        scenario: "Instead of cutting trees, milling planks, and pouring custom foundations over a year, you buy a pre-fabricated modular cabin kit. The plumbing, walls, and roof panels are pre-manufactured. You assemble them on a basic foundation in 5 days.",
        analogy: "RAD is like building a castle out of Legos. You don't manufacture the plastic blocks yourself; you snap together pre-existing blocks of various shapes to construct a fort in an hour.",
        takeaway: "Never code from scratch what you can safely reuse, purchase, or automate."
      }
    ],
    quiz: [
      {
        id: "ra_q1",
        question: "What is a JAD (Joint Application Design) session in the context of RAD?",
        options: [
          "An automated script that runs security tests on server code.",
          "An intensive collaborative workshop where users and developers sit together to design UI screens and requirements in real-time.",
          "A database clustering strategy to speed up queries.",
          "A programming language contest to hire fast typists."
        ],
        correctAnswer: 1,
        explanation: "JAD sessions are a core pillar of RAD, bringing business stakeholders and developers together to eliminate communication lags and design system requirements immediately."
      },
      {
        id: "ra_q2",
        question: "What is a major technical prerequisite for RAD to succeed in a short 60-90 day timeline?",
        options: [
          "The team must write code without any comments or formatting.",
          "A rich library of pre-built, reusable components and automated CASE tools.",
          "The server must use liquid nitrogen cooling to compile code faster.",
          "The system must bypass all testing phases."
        ],
        correctAnswer: 1,
        explanation: "RAD achieves speed through reuse. If a team has to write every module (auth, database, UI grids) from scratch, they cannot possibly meet the 90-day cutover deadline."
      }
    ],
    keyTakeaways: [
      "Drastically compresses development timelines to 60-90 days.",
      "Requires intensive, continuous commitment from business stakeholders.",
      "Relies entirely on component reusability and visual CASE development tools."
    ]
  },
  {
    id: "agile",
    title: "7. Agile Model",
    shortDescription: "Adaptable, collaborative, and fast. Build software through continuous 2-week sprints and direct user feedback.",
    emoji: "🏃",
    academicContext: "The Agile model, formalized by the Agile Manifesto in 2001, is a response to the rigid documentation of Waterfall. It asserts that software environments are too unpredictable for long-term planning. Agile breaks development into short, fixed-length iterations called 'Sprints' (usually 2 weeks), prioritizing working software, individual interactions, and a high capacity to embrace changing requirements.",
    detailedContent: [
      {
        sectionTitle: "The Iterative Sprint Mechanics",
        paragraphs: [
          "Agile uses frameworks like Scrum or Kanban. A project backlog is populated with 'User Stories' (simple descriptions of features from the user's view). Every 2 weeks, during Sprint Planning, the team selects stories they commit to completing.",
          "Each day, a Daily Standup keeps the team aligned. At the end of the sprint, the team demonstrates working software to the customer in a Sprint Review, gathers immediate feedback, and conducts a Retrospective to optimize their process for the next sprint."
        ]
      },
      {
        sectionTitle: "★ Case Study: Spotify's Desktop Player Team",
        paragraphs: [
          "Spotify manages a music streaming application used by over 500 million people across dozens of operating systems. User tastes change rapidly, and new competitor features emerge weekly.",
          "Spotify uses an Agile approach structured into autonomous 'Squads.' The Desktop Player squad manages the music play controls. Instead of planning a year-long release, they run 2-week sprints. If they want to test a new 'Smart Shuffle' button, they build a basic version, release it to 1% of users behind a feature flag, analyze streaming metrics, gather feedback, and iterate. If the feedback is poor, they delete the code and pivot. This rapid-feedback Agile method keeps Spotify highly responsive to consumer trends without halting operations."
        ]
      },
      {
        sectionTitle: "The Agile Manifesto Core Pillars",
        paragraphs: [
          "Agile is defined by four core values: 1. Individuals and interactions over processes and tools. 2. Working software over comprehensive documentation. 3. Customer collaboration over contract negotiation. 4. Responding to change over following a plan.",
          "Agile is NOT 'no documentation' or 'no planning'—that is unstructured hacking. Agile is structured, highly disciplined learning that values rapid software shipping above theoretical blueprints."
        ]
      }
    ],
    relatableExamples: [
      {
        title: "Navigating with Real-Time Google Maps GPS",
        scenario: "Instead of writing down 100 turns on a sheet of paper and driving blindly (Waterfall), you use GPS. If a road is suddenly closed or traffic spikes, the GPS immediately reroutes you on-the-fly based on real-time feedback, keeping you on track to your destination.",
        analogy: "Agile is like publishing Wikipedia: articles are updated daily, expanded as information emerges, and continually polished by readers, rather than being printed in a static encyclopedia once a decade.",
        takeaway: "In a rapidly changing world, the ability to adapt is infinitely more valuable than the perfect plan."
      }
    ],
    quiz: [
      {
        id: "ag_q1",
        question: "Which of the following is one of the core values of the Agile Manifesto?",
        options: [
          "Rigid processes and specialized tooling over individual developer interactions.",
          "Comprehensive blueprint documentation over actual working software.",
          "Responding to change over following a strict pre-determined plan.",
          "Enforcing ironclad contract negotiation over customer collaboration."
        ],
        correctAnswer: 2,
        explanation: "The Agile Manifesto values 'Responding to change over following a plan', recognizing that market, user, and technical realities shift too quickly for rigid, multi-month upfront plans to succeed."
      },
      {
        id: "ag_q2",
        question: "What is a 'Sprint' in the Scrum framework of Agile?",
        options: [
          "A race to see which developer can write the most lines of code in 24 hours.",
          "A fixed-length iteration (usually 1 to 4 weeks) during which a team builds and tests a usable, functional increment of software.",
          "The network transit speed of a data packet to the cloud server.",
          "An emergency period where developers work overtime to fix server crashes."
        ],
        correctAnswer: 1,
        explanation: "Sprints are the foundational heartbeat of Scrum, representing consistent, time-boxed cycles (commonly 2 weeks) where team progress is focused on planning, building, testing, and demonstrating working software."
      }
    ],
    keyTakeaways: [
      "Delivers working, tested software at the end of every short sprint cycle.",
      "Prioritizes human communication, direct collaboration, and rapid feedback loops.",
      "Allows changing requirements to be embraced smoothly, rather than feared."
    ]
  },
  {
    id: "dbms",
    title: "8. Introduction to DBMS",
    shortDescription: "Database Management Systems core concepts. Learn to define, store, retrieve, update, and secure structured relational data.",
    emoji: "🗄️",
    academicContext: "Database Management Systems (DBMS) form the baseline of modern computing infrastructure, acting as the bridge between software applications and raw persistent data. This module explores relational models, core data operations, and how structured management avoids the severe failures of paper/file-based systems.",
    detailedContent: [
      {
        sectionTitle: "Core Philosophy & Librarian Analogy",
        paragraphs: [
          "A Database Management System (DBMS) is a collection of programs enabling users to define, create, maintain, and control access to structured databases. Without a DBMS, data records are scattered across disconnected spreadsheets or text files, leading to severe issues: data redundancy (duplicated files), search inefficiencies, security vulnerabilities, and massive risk of data corruption or loss.",
          "Think of a traditional Library. Without a Librarian, books are scattered randomly, and searching for a specific volume is difficult, tracking borrowers is impossible, and loss is constant. With a Librarian, books are cataloged, borrowing is tracked, and security is enforced. Here, the Library represents the Database, the Librarian represents the DBMS software, the Books represent the Data, and the Visitors are the Users."
        ]
      },
      {
        sectionTitle: "★ Case Study: The WhatsApp & Amazon Scalability Engines",
        paragraphs: [
          "Modern high-scale applications could not exist without highly optimized DBMS engines. Consider WhatsApp: it stores billions of messages, media links, and group relationships across millions of concurrent users. It achieves this by routing requests through custom database engines designed for write-heavy concurrency.",
          "Similarly, Amazon processes millions of orders simultaneously. If two users click 'Buy' on the last remaining item at the exact same millisecond, the database uses ACID (Atomicity, Consistency, Isolation, Durability) transaction controls to lock the record, ensuring that only one user succeeds and data remains consistent. This prevents double-selling and financial disputes, highlighting why simple Excel files are completely inadequate for enterprise operations."
        ]
      },
      {
        sectionTitle: "The 6 Core Functions of DBMS",
        paragraphs: [
          "1. Data Storage: Safely houses massive, multi-gigabyte files (e.g., a university holding transcript records for 20,000 students).",
          "2. Data Retrieval: Fetches specific rows within milliseconds (e.g., searching a student profile instantly using their unique Roll Number).",
          "3. Data Update: Modifies existing entries safely without altering adjacent files (e.g., updating a student's mobile number).",
          "4. Data Deletion: Removes unwanted, obsolete, or duplicate records securely from disk storage.",
          "5. Data Security: Implements granular authentication rules, ensuring students can view their grades but cannot access faculty payroll.",
          "6. Backup & Recovery: Automates transactions logging, enabling the database to self-heal and recover its exact state after a sudden power loss or server crash."
        ]
      }
    ],
    relatableExamples: [
      {
        title: "The Waiter in a Modern Restaurant",
        scenario: "You enter a restaurant and order food. You (the User) do not walk into the kitchen (the Database) to cook the food yourself. Instead, you order through a Waiter (the DBMS).",
        analogy: "The Waiter takes your custom request, verifies it with the kitchen, ensures the chef processes it correctly, and serves you the warm food. A DBMS acts as this smart, protective coordinator between external users and the raw database kitchen.",
        takeaway: "Direct access to raw files is dangerous. A DBMS provides a safe, structured abstraction layer to retrieve and manipulate data."
      }
    ],
    quiz: [
      {
        id: "db_q1",
        question: "What does DBMS stand for?",
        options: [
          "Database Managing Service",
          "Database Management System",
          "Data Backup Management System",
          "Database Machine Software"
        ],
        correctAnswer: 1,
        explanation: "DBMS stands for Database Management System, which is software designed to define, create, maintain, and control access to structured databases."
      },
      {
        id: "db_q2",
        question: "Which analogy correctly maps the components of a database system to the real world?",
        options: [
          "Library is the DBMS, Librarian is the Database, Books are the Users.",
          "Library is the Database, Librarian is the DBMS, Books are the Data.",
          "Library is the Data, Librarian is the User, Books are the DBMS.",
          "Library is the User, Librarian is the Compiler, Books are the Database."
        ],
        correctAnswer: 1,
        explanation: "The Library stores all the books (Database/Data), the Librarian organizes and controls the books (DBMS), and the books are the actual info (Data)."
      },
      {
        id: "db_q3",
        question: "Which of the following is NOT a core function of a DBMS?",
        options: [
          "Compiling TypeScript source files into executable binaries.",
          "Ensuring data security by restricting unauthorized table access.",
          "Providing database backup and recovery after unexpected system crashes.",
          "Retrieving specific data rows within milliseconds using unique keys."
        ],
        correctAnswer: 0,
        explanation: "Source code compilation is handled by compilers and build systems (like Vite or TypeScript), while a DBMS manages data storage, security, retrieval, and recovery."
      },
      {
        id: "db_q4",
        question: "Why is Microsoft Excel considered inadequate as a DBMS for large-scale enterprise systems?",
        options: [
          "Excel cannot be installed on Linux operating systems.",
          "Excel sheets can only store up to 10 rows of data.",
          "Excel lacks advanced transactional locking, multi-user concurrency control, and relational integrity constraints.",
          "Excel automatically deletes data when the browser cache is cleared."
        ],
        correctAnswer: 2,
        explanation: "Excel is a great flat spreadsheet tool, but it lacks the critical concurrency locks, database security, relational mapping, and crash recovery features of a true enterprise DBMS."
      },
      {
        id: "db_q5",
        question: "Which popular relational database management system (RDBMS) is widely used by Instagram and Spotify?",
        options: [
          "MySQL Server 1995",
          "HTML5 LocalStorage",
          "PostgreSQL",
          "Babel Compiler"
        ],
        correctAnswer: 2,
        explanation: "PostgreSQL is an open-source, highly advanced relational DBMS that manages billions of user records and relationships for modern high-load apps like Instagram and Spotify."
      }
    ],
    keyTakeaways: [
      "A Database is an organized collection of related data, whereas a DBMS is the software engine used to manage it.",
      "Using disconnected flat files leads to data redundancy, inconsistent updates, and poor security.",
      "Relational databases ensure absolute transaction security and high-speed retrieval using ACID rules."
    ]
  }
];
