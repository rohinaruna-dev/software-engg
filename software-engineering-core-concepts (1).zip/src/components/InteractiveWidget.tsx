/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Zap, Shield, AlertTriangle, CheckCircle2, XCircle, Play, 
  RotateCcw, ArrowRight, Settings, Users, Layers, ShieldCheck, 
  Clock, GitPullRequest, Search, Check, FileCode, CheckSquare, Sparkles
} from "lucide-react";

interface InteractiveWidgetProps {
  moduleId: string;
  onComplete: () => void;
}

export default function InteractiveWidget({ moduleId, onComplete }: InteractiveWidgetProps) {
  // Common states
  const [complete, setComplete] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string>("");
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  useEffect(() => {
    setComplete(false);
    setFeedback("");
    setIsPlaying(false);
  }, [moduleId]);

  // --- 8. DBMS SIMULATOR STATES & FUNCTIONS ---
  interface DbRecord {
    rollNo: number;
    name: string;
    branch: string;
    attendance: number;
  }

  const [dbRecords, setDbRecords] = useState<DbRecord[]>([
    { rollNo: 101, name: "Aruna Rohini", branch: "CSE", attendance: 92 },
    { rollNo: 102, name: "Kiran Dev", branch: "ECE", attendance: 85 },
    { rollNo: 103, name: "Suresh Kumar", branch: "MECH", attendance: 78 }
  ]);
  const [dbLogs, setDbLogs] = useState<string[]>([
    "🗄️ Database engine loaded successfully.",
    "🔑 Relation 'Students' created with Primary Key (rollNo).",
    "📥 Injected 3 default student records into the memory relation."
  ]);
  const [dbActiveTab, setDbActiveTab] = useState<"table" | "insert" | "search" | "acid">("table");

  // Insert form states
  const [dbInsRollNo, setDbInsRollNo] = useState<string>("");
  const [dbInsName, setDbInsName] = useState<string>("");
  const [dbInsBranch, setDbInsBranch] = useState<string>("CSE");
  const [dbInsAttendance, setDbInsAttendance] = useState<number>(85);

  // Search states
  const [dbSearchRollNo, setDbSearchRollNo] = useState<string>("");
  const [dbSearchResult, setDbSearchResult] = useState<DbRecord | null | "not_found">(null);
  const [dbScanSteps, setDbScanSteps] = useState<number>(0);
  const [dbSearchMethod, setDbSearchMethod] = useState<"sequential" | "indexed">("sequential");

  // ACID simulation states
  const [acidLog, setAcidLog] = useState<string[]>([]);
  const [acidLockActive, setAcidLockActive] = useState<boolean>(true);
  const [acidStatus, setAcidStatus] = useState<"idle" | "running" | "success" | "anomaly">("idle");

  const resetDbSimulator = () => {
    setDbRecords([
      { rollNo: 101, name: "Aruna Rohini", branch: "CSE", attendance: 92 },
      { rollNo: 102, name: "Kiran Dev", branch: "ECE", attendance: 85 },
      { rollNo: 103, name: "Suresh Kumar", branch: "MECH", attendance: 78 }
    ]);
    setDbLogs([
      "🗄️ Database engine loaded successfully.",
      "🔑 Relation 'Students' created with Primary Key (rollNo).",
      "📥 Injected 3 default student records into the memory relation."
    ]);
    setDbActiveTab("table");
    setDbInsRollNo("");
    setDbInsName("");
    setDbInsBranch("CSE");
    setDbInsAttendance(85);
    setDbSearchRollNo("");
    setDbSearchResult(null);
    setDbScanSteps(0);
    setDbSearchMethod("sequential");
    setAcidLog([]);
    setAcidLockActive(true);
    setAcidStatus("idle");
    setFeedback("");
    setComplete(false);
  };

  const handleDbInsert = () => {
    const rNo = parseInt(dbInsRollNo);
    if (!rNo || isNaN(rNo)) {
      alert("Please enter a valid numeric Roll Number.");
      return;
    }
    if (!dbInsName.trim()) {
      alert("Please enter a student Name.");
      return;
    }
    if (dbRecords.some(r => r.rollNo === rNo)) {
      setDbLogs(prev => [
        `❌ [INSERT FAILED] Primary Key Violation! Roll Number ${rNo} already exists in Students relation.`,
        ...prev
      ]);
      return;
    }

    const newRec: DbRecord = {
      rollNo: rNo,
      name: dbInsName.trim(),
      branch: dbInsBranch,
      attendance: Number(dbInsAttendance)
    };

    setDbRecords(prev => [...prev, newRec]);
    setDbLogs(prev => [
      `📥 [INSERT SUCCESS] SQL: INSERT INTO Students (rollNo, name, branch, attendance) VALUES (${rNo}, '${dbInsName.trim()}', '${dbInsBranch}', ${dbInsAttendance});`,
      `✅ Record appended successfully: ${dbInsName} (Roll: ${rNo})`,
      ...prev
    ]);

    setDbInsRollNo("");
    setDbInsName("");
    
    // Check if they successfully inserted their own custom student or grew the database
    if (dbRecords.length >= 4) {
      setComplete(true);
      onComplete();
      setFeedback("Excellent! You successfully completed a database insert with full primary key constraint validation. Your data is cataloged safely!");
    }
  };

  const handleDbDelete = (rNo: number) => {
    setDbRecords(prev => prev.filter(r => r.rollNo !== rNo));
    setDbLogs(prev => [
      `🗑️ [DELETE SUCCESS] SQL: DELETE FROM Students WHERE rollNo = ${rNo};`,
      `✅ Removed student with Roll: ${rNo}`,
      ...prev
    ]);
  };

  const handleDbSearch = () => {
    const rNo = parseInt(dbSearchRollNo);
    if (!rNo || isNaN(rNo)) {
      alert("Please enter a valid numeric Roll Number to query.");
      return;
    }

    const foundIdx = dbRecords.findIndex(r => r.rollNo === rNo);
    
    let steps = 0;
    if (dbSearchMethod === "sequential") {
      // Sequential scan checks each record from 0 to found index (or total length if not found)
      steps = foundIdx !== -1 ? foundIdx + 1 : dbRecords.length;
    } else {
      // Indexed scan uses primary key index tree - always takes exactly 1 step (O(1))!
      steps = foundIdx !== -1 ? 1 : 1;
    }

    setDbScanSteps(steps);

    if (foundIdx !== -1) {
      setDbSearchResult(dbRecords[foundIdx]);
      setDbLogs(prev => [
        `🔍 [QUERY SUCCESS] SQL: SELECT * FROM Students WHERE rollNo = ${rNo};`,
        `⚡ Search stats: Method: ${dbSearchMethod.toUpperCase()} | Cost: ${steps} block access(es).`,
        ...prev
      ]);
    } else {
      setDbSearchResult("not_found");
      setDbLogs(prev => [
        `🔍 [QUERY EMPTY] SQL: SELECT * FROM Students WHERE rollNo = ${rNo};`,
        `⚠️ Warning: Zero records found. Method: ${dbSearchMethod.toUpperCase()} | Cost: ${steps} block access(es).`,
        ...prev
      ]);
    }
  };

  const runAcidSimulation = async () => {
    setAcidStatus("running");
    setAcidLog(["🚀 Transaction T1 & T2 initiated simultaneously...", "🔄 T1: Update Attendance (+5%) for Aruna (Roll 101)", "🔄 T2: Update Attendance (-10%) for Aruna (Roll 101)"]);
    await new Promise(r => setTimeout(r, 800));

    if (acidLockActive) {
      // WITH LOCKS: Sequential, serializable execution
      setAcidLog(prev => [...prev, "🔒 T1 requests Lock on Student 101. Lock GRANTED (Exclusive).", "🕒 T2 requests Lock on Student 101. T2 is put in WAITING state..."]);
      await new Promise(r => setTimeout(r, 1000));
      
      const currentVal = dbRecords.find(r => r.rollNo === 101)?.attendance || 92;
      const t1Val = currentVal + 5;
      setAcidLog(prev => [...prev, `💾 T1 reads attendance = ${currentVal}%`, `✏️ T1 calculates: ${currentVal} + 5 = ${t1Val}%`, `📥 T1 writes back ${t1Val}% to storage and releases Lock.`]);
      
      setDbRecords(prev => prev.map(r => r.rollNo === 101 ? { ...r, attendance: t1Val } : r));
      await new Promise(r => setTimeout(r, 1000));

      setAcidLog(prev => [...prev, "🔓 T2 wakes up and acquires Lock on Student 101.", `💾 T2 reads current attendance = ${t1Val}%`, `✏️ T2 calculates: ${t1Val} - 10 = ${t1Val - 10}%`, `📥 T2 writes back ${t1Val - 10}% and commits.`]);
      
      const t2Val = t1Val - 10;
      setDbRecords(prev => prev.map(r => r.rollNo === 101 ? { ...r, attendance: t2Val } : r));
      
      setAcidStatus("success");
      setAcidLog(prev => [...prev, "🎉 [ACID SUCCESS] Both transactions completed with proper isolation. Final attendance is mathematically correct (87%)."]);
      setComplete(true);
      onComplete();
      setFeedback("Amazing! You demonstrated ACID Isolation. With lock-based concurrency control enabled, the database executes transactions serially, avoiding the lost update anomaly.");
    } else {
      // WITHOUT LOCKS: Lost Update Anomaly (Race condition!)
      setAcidLog(prev => [...prev, "⚠️ CONCURRENCY WARNING: Locking disabled. No transaction isolation!", "💾 T1 reads attendance = 92%", "💾 T2 reads attendance = 92% (Concurrent Read!)"]);
      await new Promise(r => setTimeout(r, 1000));
      
      setAcidLog(prev => [...prev, "✏️ T2 calculates: 92 - 10 = 82%", "📥 T2 writes back 82% to storage.", "✏️ T1 calculates: 92 + 5 = 97%"]);
      setDbRecords(prev => prev.map(r => r.rollNo === 101 ? { ...r, attendance: 82 } : r));
      await new Promise(r => setTimeout(r, 1000));

      setAcidLog(prev => [...prev, "📥 T1 writes back 97% to storage (Overwriting T2's update!)", "🚨 [LOST UPDATE ANOMALY] Transaction T2's modification (-10%) was completely lost! T1 overwrote it because of lack of isolation."]);
      setDbRecords(prev => prev.map(r => r.rollNo === 101 ? { ...r, attendance: 97 } : r));
      setAcidStatus("anomaly");
      setFeedback("Lost Update Anomaly occurred! Because locking was disabled, T1 and T2 read the same stale value simultaneously. T1 overwrote T2's write, corrupting the ledger. This is why multi-user applications require a robust DBMS!");
    }
  };

  // --- 1. WATERFALL SIMULATOR ---
  const [wfRequirements, setWfRequirements] = useState<number>(90); // Clarity
  const [wfChanges, setWfChanges] = useState<number>(10); // Change Frequency
  const [wfPhase, setWfPhase] = useState<number>(-1); // -1: Not started, 0: Requirements, 1: Design, 2: Code, 3: Test, 4: Deploy
  const [wfLog, setWfLog] = useState<string[]>([]);
  const [wfStatus, setWfStatus] = useState<"success" | "failed" | "idle">("idle");

  const runWaterfallSimulation = async () => {
    setIsPlaying(true);
    setWfPhase(0);
    setWfStatus("idle");
    const logs = ["🏁 Starting Waterfall Process. Upfront planning phase active..."];
    setWfLog(logs);

    const phases = [
      { name: "Requirements Analysis", delay: 1000 },
      { name: "System Design Blueprinting", delay: 1000 },
      { name: "Monolithic Implementation (Coding)", delay: 1000 },
      { name: "Integration & Heavy Testing", delay: 1200 },
      { name: "Deployment & Customer Delivery", delay: 1000 }
    ];

    for (let i = 0; i < phases.length; i++) {
      setWfPhase(i);
      await new Promise((resolve) => setTimeout(resolve, phases[i].delay));
      
      if (i === 0) {
        if (wfRequirements < 75) {
          logs.unshift("⚠️ Warning: Requirements clarity is low. Continuing linear waterfall anyway without customer reviews.");
        } else {
          logs.unshift("✅ System specs locked, signed off, and stored in a 200-page document.");
        }
      }
      if (i === 1) {
        logs.unshift("✅ Architecture schemas finished. UML diagrams completely drawn based on frozen requirements.");
      }
      if (i === 2) {
        logs.unshift("✅ Coding underway. All database modules, layouts, and controllers are built to matching frozen specs.");
      }
      if (i === 3) {
        // High changes or low requirements cause disaster at Testing phase
        if (wfChanges > 40 || wfRequirements < 70) {
          setWfStatus("failed");
          logs.unshift("🚨 CRITICAL COLLAPSE IN TESTING PHASE! Customer noticed the software solves the wrong problem. Mid-project changes have broken the database links. Massive manual rollbacks needed.");
          setWfLog([...logs]);
          setIsPlaying(false);
          setFeedback("Waterfall Monolith Crashed! Because requirements shifted or were initially ambiguous, the massive upfront code failed at integration. Real engineers avoid Waterfall for highly dynamic environments!");
          return;
        } else {
          logs.unshift("✅ Integration complete. Zero anomalies detected because requirements and environment are completely stable.");
        }
      }
      if (i === 4) {
        setWfStatus("success");
        logs.unshift("🎉 SUCCESS! Software successfully compiled and deployed on budget with zero flight defects!");
        setWfLog([...logs]);
        setIsPlaying(false);
        setFeedback("Flawless Waterfall Execution! Since specifications were fully clear and zero changes occurred, your upfront architecture completed perfectly. NASA would be proud.");
        setComplete(true);
        onComplete();
        return;
      }
      setWfLog([...logs]);
    }
  };

  const resetWaterfall = () => {
    setWfRequirements(90);
    setWfChanges(10);
    setWfPhase(-1);
    setWfLog([]);
    setWfStatus("idle");
    setFeedback("");
    setComplete(false);
    setIsPlaying(false);
  };


  // --- 2. INCREMENTAL SIMULATOR ---
  const [incPhase, setIncPhase] = useState<number>(-1); // -1: Idle, 0: Inc1, 1: Inc2, 2: Inc3
  const [incChangesActive, setIncChangesActive] = useState<boolean>(false);
  const [incLogs, setIncLogs] = useState<string[]>([]);
  const [incArchitectureQuality, setIncArchitectureQuality] = useState<number>(85); // Slider

  const runIncrementalSimulation = async () => {
    setIsPlaying(true);
    setIncPhase(0);
    const logs = ["🚀 Initializing Modular Architecture Skeleton..."];
    setIncLogs(logs);

    // Increment 1: Core Engine
    await new Promise((resolve) => setTimeout(resolve, 1000));
    logs.unshift("🪜 Delivering Increment 1: Core database structures & user login setup.");
    logs.unshift("✨ Core Product released! Users are actively logged in and generating system usage data.");
    setIncPhase(1);
    setIncLogs([...logs]);

    // Increment 2: Payments / Dashboard
    await new Promise((resolve) => setTimeout(resolve, 1200));
    logs.unshift("🪜 Delivering Increment 2: Rich user dashboard & checkout modules.");
    if (incChangesActive) {
      logs.unshift("🔄 Mid-project change detected: Customer wants automatic Dark Mode.");
      if (incArchitectureQuality < 70) {
        logs.unshift("❌ Architectural Mismatch! Low-quality skeleton caused dark mode to break standard styles. Regression bugs found.");
        setIncLogs([...logs]);
        setIsPlaying(false);
        setFeedback("Increment Integration Error! Because your initial architecture quality was too low, appending the dark mode modification broke your core screens. High-quality skeletons are mandatory for Incremental development!");
        return;
      } else {
        logs.unshift("✅ Modular design successfully absorbed Dark Mode within the active release window!");
      }
    }
    logs.unshift("✨ Phase 2 fully deployed and functioning perfectly.");
    setIncPhase(2);
    setIncLogs([...logs]);

    // Increment 3: Analytics
    await new Promise((resolve) => setTimeout(resolve, 1200));
    logs.unshift("🪜 Delivering Increment 3: Global Analytics engine and reporting panel.");
    logs.unshift("🎉 Final release unified and fully synchronized in production.");
    setIncLogs([...logs]);
    setIsPlaying(false);
    setFeedback("Superb Phased Delivery! By modularizing features, you launched a core system early to earn revenue, while successfully integrating subsequent changes.");
    setComplete(true);
    onComplete();
  };

  const resetIncremental = () => {
    setIncPhase(-1);
    setIncChangesActive(false);
    setIncLogs([]);
    setIncArchitectureQuality(85);
    setFeedback("");
    setComplete(false);
    setIsPlaying(false);
  };


  // --- 3. PROTOTYPE SIMULATOR ---
  const [protoScreen, setProtoScreen] = useState<"menu" | "building" | "testing">("menu");
  const [protoFeedback, setProtoFeedback] = useState<string[]>([]);
  const [protoFit, setProtoFit] = useState<number>(30); // Market Fit
  const [protoFeatures, setProtoFeatures] = useState<string[]>([]);
  const [protoIteration, setProtoIteration] = useState<number>(1);

  const availableProtoFeatures = [
    { id: "voice", label: "🎙️ Voice Command Shortcuts", rating: 25 },
    { id: "checkout", label: "💳 1-Click Fast Checkout", rating: 40 },
    { id: "analytics", label: "📊 Complex CSV Report Exporter", rating: 10 },
    { id: "minimalist", label: "🎨 Clean, High-Contrast Interface", rating: 35 },
    { id: "dark_mode", label: "🌙 System-wide Dark Mode Toggle", rating: 20 }
  ];

  const handleToggleFeature = (fid: string) => {
    if (protoFeatures.includes(fid)) {
      setProtoFeatures(protoFeatures.filter(x => x !== fid));
    } else {
      if (protoFeatures.length >= 3) return; // limit to 3 mockups
      setProtoFeatures([...protoFeatures, fid]);
    }
  };

  const handleTestPrototype = () => {
    if (protoFeatures.length === 0) return;
    setProtoScreen("testing");
    setIsPlaying(true);
    
    // Calculate simulated fit
    let totalScore = 15;
    protoFeatures.forEach(fid => {
      const match = availableProtoFeatures.find(f => f.id === fid);
      if (match) totalScore += match.rating;
    });

    if (protoFeatures.includes("checkout") && protoFeatures.includes("minimalist")) {
      totalScore += 20; // High synergy bonus!
    }

    if (totalScore > 100) totalScore = 100;
    
    // Generate feedback quotes
    const quotes: string[] = [];
    if (protoFeatures.includes("voice")) {
      quotes.push("🗣️ Mock User A: 'Voice actions are fancy, but standard search works faster.'");
    }
    if (protoFeatures.includes("checkout")) {
      quotes.push("💳 Mock User B: 'Adding the quick checkout mockup was incredible, so fast!'");
    }
    if (protoFeatures.includes("minimalist")) {
      quotes.push("🎨 Mock User C: 'The visual structure is so clean, I immediately understand it.'");
    } else {
      quotes.push("😕 Mock User C: 'The UI is cluttered. I can't find anything without a layout tutorial.'");
    }
    if (protoFeatures.includes("analytics")) {
      quotes.push("📈 Mock User D: 'The CSV export is a bit complex for a mobile app mockup.'");
    }

    setProtoFeedback(quotes);
    setProtoFit(totalScore);
    setIsPlaying(false);
  };

  const iteratePrototype = () => {
    setProtoIteration(prev => prev + 1);
    setProtoScreen("building");
    setProtoFeatures([]);
  };

  const submitProductionBuild = () => {
    if (protoFit >= 75) {
      setFeedback(`Perfect Requirements Gathering! Through ${protoIteration} prototype loops, you discovered that users wanted checkout efficiency and a clean interface. Your final system matches user desires perfectly!`);
      setComplete(true);
      onComplete();
    } else {
      setFeedback("Market Fit too low! Users are still confused. Adjust feature combinations to reach at least 75% market fit.");
    }
  };

  const resetPrototype = () => {
    setProtoScreen("menu");
    setProtoFeedback([]);
    setProtoFit(30);
    setProtoFeatures([]);
    setProtoIteration(1);
    setFeedback("");
    setComplete(false);
  };


  // --- 4. V-MODEL SYMMETRICAL PUZZLE ---
  // Connect Left Symmetrical stage to Right verification stage
  const devStages = [
    { id: "biz", label: "Business Requirements Spec" },
    { id: "sys", label: "System Specifications Plan" },
    { id: "arch", label: "High-Level System Architecture" },
    { id: "unit", label: "Low-Level Module Code" }
  ];

  const testStages = [
    { id: "unit_test", label: "Unit Testing", pairsWith: "unit" },
    { id: "integration_test", label: "Integration Testing", pairsWith: "arch" },
    { id: "system_test", label: "System Testing", pairsWith: "sys" },
    { id: "uat_test", label: "User Acceptance Testing (UAT)", pairsWith: "biz" }
  ];

  const [selectedDev, setSelectedDev] = useState<string | null>(null);
  const [connections, setConnections] = useState<Record<string, string>>({}); // devId -> testId
  const [vFeedback, setVFeedback] = useState<string>("");

  const handleDevClick = (devId: string) => {
    setSelectedDev(devId);
  };

  const handleTestClick = (testId: string, pairsWith: string) => {
    if (!selectedDev) {
      setVFeedback("⚠️ First, select a development phase on the left column!");
      return;
    }

    if (selectedDev === pairsWith) {
      setConnections(prev => ({ ...prev, [selectedDev]: testId }));
      setVFeedback("✅ Perfect symmetrical match! Test aligns with design spec.");
      setSelectedDev(null);

      // Check if all connected
      const nextConns = { ...connections, [selectedDev]: testId };
      if (Object.keys(nextConns).length === 4) {
        setFeedback("Incredible precision! You mapped all Symmetrical Slices of the V-Model. Every specification is now verified by its precise matching testing pipeline!");
        setComplete(true);
        onComplete();
      }
    } else {
      setVFeedback("❌ Misaligned testing criteria! That test does not verify this level of design.");
    }
  };

  const resetVModel = () => {
    setSelectedDev(null);
    setConnections({});
    setVFeedback("");
    setFeedback("");
    setComplete(false);
  };


  // --- 5. SPIRAL RISK-MITIGATION LOOP ---
  const [spiralLoop, setSpiralLoop] = useState<number>(1); // Loops 1, 2, 3
  const [spiralQuadrant, setSpiralQuadrant] = useState<number>(0); // 0: Objectives, 1: Risk Analysis, 2: Coding/Test, 3: Next Loop
  const [spiralRisks, setSpiralRisks] = useState<string[]>([
    "⚡ Unstable Third-party Payment API",
    "🔒 Potential SQL Injection Security Gap",
    "⚙️ High Server Crash under 5,000 Concurrent Writes"
  ]);
  const [mitigationsSelected, setMitigationsSelected] = useState<string[]>([]);
  const [spiralBudget, setSpiralBudget] = useState<number>(120000); // Start with $120,000
  const [spiralLogs, setSpiralLogs] = useState<string[]>([]);

  const availableMitigations = [
    { id: "benchmark", label: "🛠️ Run Concurrent Load Benchmarks ($20k)", cost: 20000, targets: "⚙️ High Server Crash under 5,000 Concurrent Writes" },
    { id: "sandbox", label: "💳 Construct payment API sandbox sandbox ($15k)", cost: 15000, targets: "⚡ Unstable Third-party Payment API" },
    { id: "audit", label: "🛡️ Run a thorough static security scan ($25k)", cost: 25000, targets: "🔒 Potential SQL Injection Security Gap" },
    { id: "ui", label: "🎨 Standard UI design polish ($10k)", cost: 10000, targets: "" }
  ];

  const handleApplyMitigation = (mid: string, cost: number, targets: string) => {
    if (spiralBudget < cost) {
      setSpiralLogs(prev => ["❌ Out of budget for this mitigation!", ...prev]);
      return;
    }
    if (mitigationsSelected.includes(mid)) return;

    setSpiralBudget(prev => prev - cost);
    setMitigationsSelected(prev => [...prev, mid]);
    
    if (targets) {
      setSpiralRisks(prev => prev.filter(r => r !== targets));
      setSpiralLogs(prev => [`✅ MITIGATED: Successfully eliminated risk '${targets}'`, ...prev]);
    } else {
      setSpiralLogs(prev => ["🎨 Polished interfaces. However, high structural risks still loom!", ...prev]);
    }
  };

  const proceedSpiralLoop = () => {
    if (spiralLoop === 1) {
      setSpiralLoop(2);
      setSpiralLogs(prev => ["🌀 Spiral loop 2 initiated. Evaluating second-level systems...", ...prev]);
    } else if (spiralLoop === 2) {
      setSpiralLoop(3);
      setSpiralLogs(prev => ["🌀 Final Spiral loop 3 active. Securing release architecture...", ...prev]);
    } else {
      // Finished 3 loops
      if (spiralRisks.length === 0) {
        setFeedback(`Outstanding Risk-First Engineering! You completed 3 spiral rotations and successfully mitigated all core security, payment, and concurrency risks with $${spiralBudget.toLocaleString()} of budget remaining!`);
        setComplete(true);
        onComplete();
      } else {
        setFeedback("Simulation incomplete. You ran out of loops and left unresolved risks active in production, leading to a system breach!");
      }
    }
  };

  const resetSpiral = () => {
    setSpiralLoop(1);
    setSpiralQuadrant(0);
    setSpiralRisks([
      "⚡ Unstable Third-party Payment API",
      "🔒 Potential SQL Injection Security Gap",
      "⚙️ High Server Crash under 5,000 Concurrent Writes"
    ]);
    setMitigationsSelected([]);
    setSpiralBudget(120000);
    setSpiralLogs([]);
    setFeedback("");
    setComplete(false);
  };


  // --- 6. RAPID APPLICATION DEVELOPMENT (RAD) SIMULATOR ---
  const [radReuse, setRadReuse] = useState<number>(85); // Component Reusability Slider
  const [radJad, setRadJad] = useState<number>(90); // JAD Session Participation Slider
  const [radDay, setRadDay] = useState<number>(0);
  const [radLogs, setRadLogs] = useState<string[]>([]);
  const [radStatus, setRadStatus] = useState<"idle" | "running" | "success" | "failed">("idle");

  const runRadSimulation = async () => {
    setRadStatus("running");
    setIsPlaying(true);
    let logList = ["⚡ Kickoff! Starting 90-day RAD construction timebox."];
    setRadLogs(logList);

    const phases = [
      { name: "Requirements definition via JAD sessions", startDay: 1, duration: 15 },
      { name: "Parallel component building & UI assembly", startDay: 16, duration: 40 },
      { name: "Final integration, test, and cutover", startDay: 56, duration: 34 }
    ];

    for (let day = 1; day <= 90; day += 5) {
      setRadDay(day);
      await new Promise((resolve) => setTimeout(resolve, 150));

      if (day === 16) {
        if (radJad < 70) {
          logList.unshift("⚠️ Delay: Users missed the JAD workshops. Requirements were misunderstood.");
        } else {
          logList.unshift("👥 JAD session completed with high alignment. Visual mocks approved!");
        }
      }

      if (day === 51) {
        if (radReuse < 65) {
          logList.unshift("❌ Disaster: No pre-built modules were reusable! Developers are coding authentication from scratch.");
        } else {
          logList.unshift("📦 Integrated pre-existing login templates and library grid systems effortlessly.");
        }
      }

      setRadLogs([...logList]);
    }

    // Final assessment at day 90
    if (radReuse >= 70 && radJad >= 70) {
      setRadStatus("success");
      setFeedback("RAD Speedrun Accomplished! Thanks to high component reusability and interactive JAD customer workshops, you assembled the stock portal in record time and cut over to production successfully!");
      setComplete(true);
      onComplete();
    } else {
      setRadStatus("failed");
      setFeedback("Cutover Failed! Because of poor component reuse or low user feedback, the team couldn't assemble the code within the 90-day timebox.");
    }
    setIsPlaying(false);
  };

  const resetRad = () => {
    setRadReuse(85);
    setRadJad(90);
    setRadDay(0);
    setRadLogs([]);
    setRadStatus("idle");
    setFeedback("");
    setComplete(false);
    setIsPlaying(false);
  };


  // --- 7. AGILE SIMULATOR (KANBAN SPRINTS) ---
  const [agileSprint, setAgileSprint] = useState<number>(1);
  const [agileVelocity, setAgileVelocity] = useState<number>(15); // points per sprint
  const [agileScope, setAgileScope] = useState<number>(10); // Scope Bloat (slider)
  const [kanbanTasks, setKanbanTasks] = useState([
    { id: "task1", title: "🔑 US-101: Secure OAuth2 API Login", pts: 5, col: "backlog" },
    { id: "task2", title: "💳 US-102: Stripe payment handler", pts: 8, col: "backlog" },
    { id: "task3", title: "📊 US-103: Dynamic user reports slider", pts: 3, col: "backlog" },
    { id: "task4", title: "🔔 US-104: WebSocket push notices", pts: 5, col: "backlog" }
  ]);
  const [agileLogs, setAgileLogs] = useState<string[]>([]);

  const runSprintCycle = async () => {
    setIsPlaying(true);
    setAgileLogs(prev => [`🏃 Starting Sprint ${agileSprint} planning session...`, ...prev]);

    // Move items to In Progress
    setKanbanTasks(prev => prev.map(t => t.col === "backlog" ? { ...t, col: "progress" } : t));
    await new Promise(r => setTimeout(r, 800));

    // Evaluate based on velocity and scope bloat
    const totalPoints = kanbanTasks.reduce((sum, t) => sum + t.pts, 0);
    const capacity = agileVelocity - Math.round(agileScope / 2);

    if (capacity >= totalPoints) {
      // All tasks complete
      setKanbanTasks(prev => prev.map(t => ({ ...t, col: "done" })));
      setAgileLogs(prev => [
        `✨ Sprint Review: Successfully demonstrated all working software to the customer! All stories deployed.`,
        ...prev
      ]);
      setFeedback("Sensational Scrum Masterwork! You balanced team velocity against scope bloat, allowing all customer stories to complete smoothly in a single sprint!");
      setComplete(true);
      onComplete();
    } else {
      // Some tasks stuck or rollover
      setKanbanTasks(prev => {
        let currentCompleted = 0;
        return prev.map(t => {
          if (currentCompleted + t.pts <= capacity) {
            currentCompleted += t.pts;
            return { ...t, col: "done" };
          }
          return { ...t, col: "review" }; // Stuck in code review/QA due to bottleneck
        });
      });
      setAgileLogs(prev => [
        `⚠️ Sprint Retrospective: Some stories rolled over. Scope bloat exceeded velocity capacity. Re-balance team parameters!`,
        ...prev
      ]);
    }
    setAgileSprint(prev => prev + 1);
    setIsPlaying(false);
  };

  const resetAgile = () => {
    setAgileSprint(1);
    setAgileVelocity(15);
    setAgileScope(10);
    setKanbanTasks([
      { id: "task1", title: "🔑 US-101: Secure OAuth2 API Login", pts: 5, col: "backlog" },
      { id: "task2", title: "💳 US-102: Stripe payment handler", pts: 8, col: "backlog" },
      { id: "task3", title: "📊 US-103: Dynamic user reports slider", pts: 3, col: "backlog" },
      { id: "task4", title: "🔔 US-104: WebSocket push notices", pts: 5, col: "backlog" }
    ]);
    setAgileLogs([]);
    setFeedback("");
    setComplete(false);
    setIsPlaying(false);
  };


  // --- UNIVERSAL SIMULATOR FRAME RENDER ---
  return (
    <div className="w-full h-full flex flex-col" id="simulator_frame">
      
      {/* 1. WATERFALL MODULE SIMULATOR */}
      {moduleId === "waterfall" && (
        <div className="p-5 md:p-6 bg-white dark:bg-zinc-900 border-2 border-zinc-900 dark:border-zinc-700 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] rounded-2xl text-zinc-900 dark:text-zinc-100" id="importance_game">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b-2 border-zinc-900 dark:border-zinc-700 pb-4 mb-4">
            <div>
              <h3 className="text-lg md:text-xl font-black uppercase tracking-tight text-indigo-600 dark:text-yellow-400">🌊 Monolithic Waterfall Simulator</h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">Experience the absolute rigidity of linear software execution.</p>
            </div>
            <button onClick={resetWaterfall} className="p-2 bg-zinc-100 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl hover:bg-zinc-200 cursor-pointer self-start md:self-auto shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-mono text-xs font-bold">
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-zinc-50 dark:bg-zinc-800/50 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl space-y-4">
                <span className="text-[10px] font-bold font-mono text-indigo-600 dark:text-indigo-400 tracking-widest uppercase block">PROJECT BOUNDARIES</span>
                
                <div>
                  <div className="flex justify-between text-xs font-bold mb-1">
                    <span className="flex items-center gap-1"><CheckSquare className="h-3.5 w-3.5" /> Requirements Clarity</span>
                    <span className="font-mono text-indigo-600 dark:text-yellow-400">{wfRequirements}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="10" 
                    max="100" 
                    disabled={isPlaying}
                    value={wfRequirements} 
                    onChange={(e) => setWfRequirements(parseInt(e.target.value))}
                    className="w-full accent-indigo-600 cursor-pointer"
                  />
                  <p className="text-[10px] text-zinc-500 mt-1">If low, specs will be ambiguous at the testing phase.</p>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-bold mb-1">
                    <span className="flex items-center gap-1"><AlertTriangle className="h-3.5 w-3.5 text-yellow-500" /> Change Frequency</span>
                    <span className="font-mono text-red-500">{wfChanges}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="100" 
                    disabled={isPlaying}
                    value={wfChanges} 
                    onChange={(e) => setWfChanges(parseInt(e.target.value))}
                    className="w-full accent-red-500 cursor-pointer"
                  />
                  <p className="text-[10px] text-zinc-500 mt-1">Likelihood of customers altering rules mid-development.</p>
                </div>

                <button 
                  onClick={runWaterfallSimulation}
                  disabled={isPlaying}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs uppercase rounded-xl border-2 border-zinc-900 dark:border-zinc-700 cursor-pointer shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] disabled:opacity-40"
                >
                  {isPlaying ? "🔄 Simulating Pipeline..." : "▶ Start Monolith Build"}
                </button>
              </div>
            </div>

            <div className="lg:col-span-7 space-y-4">
              {/* Visual Pipeline progress */}
              <div className="border-2 border-zinc-900 dark:border-zinc-700 p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/80">
                <span className="text-[10px] font-bold font-mono text-zinc-500 tracking-widest uppercase block mb-3">LINEAR PIPELINE STATUS</span>
                
                <div className="space-y-2">
                  {["Requirements", "Design", "Implementation", "Verification", "Deployment"].map((pName, idx) => {
                    const isPassed = wfPhase > idx;
                    const isCurrent = wfPhase === idx;
                    return (
                      <div 
                        key={pName} 
                        className={`p-2.5 border-2 rounded-lg flex items-center justify-between text-xs transition duration-200 ${
                          isCurrent 
                            ? "bg-yellow-200 border-zinc-900 dark:text-zinc-950 font-bold" 
                            : isPassed 
                              ? "bg-emerald-50 dark:bg-emerald-900/20 border-emerald-500 text-emerald-800 dark:text-emerald-400" 
                              : "bg-white dark:bg-zinc-900 border-zinc-300 dark:border-zinc-800 text-zinc-400"
                        }`}
                      >
                        <span className="font-bold">{idx + 1}. {pName}</span>
                        {isPassed && <CheckCircle2 className="h-4 w-4 text-emerald-500" />}
                        {isCurrent && <Play className="h-4 w-4 text-zinc-900 animate-pulse fill-current" />}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Logs */}
              <div className="h-32 overflow-y-auto font-mono text-[10px] bg-zinc-950 text-emerald-400 p-3 rounded-xl border border-zinc-800 space-y-1">
                {wfLog.map((log, idx) => (
                  <div key={idx} className="leading-relaxed">{log}</div>
                ))}
                {wfLog.length === 0 && <span className="text-zinc-500">// Configure parameters and hit start.</span>}
              </div>
            </div>
          </div>

          {feedback && (
            <div className={`mt-5 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl flex items-start gap-3 ${wfStatus === "success" ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-900 dark:text-emerald-300" : "bg-red-50 dark:bg-red-950/20 text-red-900 dark:text-red-300"}`}>
              {wfStatus === "success" ? <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" /> : <XCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />}
              <div>
                <span className="font-bold text-xs uppercase block">SIMULATION REPORT</span>
                <p className="text-xs font-medium mt-1 leading-relaxed">{feedback}</p>
              </div>
            </div>
          )}
        </div>
      )}


      {/* 2. INCREMENTAL SIMULATOR */}
      {moduleId === "incremental" && (
        <div className="p-5 md:p-6 bg-white dark:bg-zinc-900 border-2 border-zinc-900 dark:border-zinc-700 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] rounded-2xl text-zinc-900 dark:text-zinc-100" id="problem_solving_game">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b-2 border-zinc-900 dark:border-zinc-700 pb-4 mb-4">
            <div>
              <h3 className="text-lg md:text-xl font-black uppercase tracking-tight text-indigo-600 dark:text-yellow-400">🪜 Phased Incremental Sandbox</h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">Assemble software layer-by-layer and evaluate feedback.</p>
            </div>
            <button onClick={resetIncremental} className="p-2 bg-zinc-100 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl hover:bg-zinc-200 cursor-pointer self-start md:self-auto shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-mono text-xs font-bold">
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-zinc-50 dark:bg-zinc-800/50 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl space-y-4">
                <span className="text-[10px] font-bold font-mono text-indigo-600 dark:text-indigo-400 tracking-widest uppercase block">CONSTRUCTION SETTINGS</span>
                
                <div>
                  <div className="flex justify-between text-xs font-bold mb-1">
                    <span className="flex items-center gap-1"><Layers className="h-3.5 w-3.5" /> Architectural Quality</span>
                    <span className="font-mono text-indigo-600 dark:text-yellow-400">{incArchitectureQuality}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="30" 
                    max="100" 
                    disabled={isPlaying}
                    value={incArchitectureQuality} 
                    onChange={(e) => setIncArchitectureQuality(parseInt(e.target.value))}
                    className="w-full accent-indigo-600 cursor-pointer"
                  />
                  <p className="text-[10px] text-zinc-500 mt-1">Crucial for integrating subsequent feature layers seamlessly.</p>
                </div>

                <div className="flex items-center justify-between p-2.5 bg-white dark:bg-zinc-900 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl">
                  <div className="flex flex-col">
                    <span className="text-xs font-bold flex items-center gap-1"><AlertTriangle className="h-3.5 w-3.5 text-yellow-500" /> Mid-project Changes</span>
                    <span className="text-[10px] text-zinc-500">Inject unexpected requirement.</span>
                  </div>
                  <input 
                    type="checkbox" 
                    checked={incChangesActive}
                    onChange={(e) => setIncChangesActive(e.target.checked)}
                    disabled={isPlaying}
                    className="w-4 h-4 cursor-pointer accent-indigo-600"
                  />
                </div>

                <button 
                  onClick={runIncrementalSimulation}
                  disabled={isPlaying}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs uppercase rounded-xl border-2 border-zinc-900 dark:border-zinc-700 cursor-pointer shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] disabled:opacity-40"
                >
                  {isPlaying ? "🛠️ Deploying Increments..." : "▶ Build Phase Iterations"}
                </button>
              </div>
            </div>

            <div className="lg:col-span-7 space-y-4">
              {/* Incremental Timeline Visual */}
              <div className="border-2 border-zinc-900 dark:border-zinc-700 p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/80">
                <span className="text-[10px] font-bold font-mono text-zinc-500 tracking-widest uppercase block mb-4">SEQUENTIAL LAUNCH STAGES</span>
                
                <div className="grid grid-cols-3 gap-3 relative">
                  {/* Line decoration */}
                  <div className="absolute top-1/2 left-4 right-4 h-0.5 bg-zinc-300 dark:bg-zinc-700 -translate-y-1/2 z-0"></div>

                  {[
                    { title: "Inc 1: Core", desc: "Database & Authentication" },
                    { title: "Inc 2: Suite", desc: "Payments & Dashboard" },
                    { title: "Inc 3: Reports", desc: "Analytics & Automation" }
                  ].map((inc, idx) => {
                    const isPassed = incPhase > idx;
                    const isCurrent = incPhase === idx;
                    return (
                      <div 
                        key={inc.title}
                        className={`p-3 border-2 rounded-xl text-center flex flex-col items-center justify-center gap-1 z-10 transition duration-300 ${
                          isCurrent 
                            ? "bg-yellow-200 border-zinc-900 dark:text-zinc-950 font-bold scale-105 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                            : isPassed 
                              ? "bg-emerald-50 dark:bg-emerald-900/20 border-emerald-500 text-emerald-850 dark:text-emerald-400"
                              : "bg-white dark:bg-zinc-900 border-zinc-300 dark:border-zinc-800 text-zinc-400"
                        }`}
                      >
                        <span className="text-xs font-black uppercase font-mono">{inc.title}</span>
                        <span className="text-[9px] leading-tight font-medium opacity-80">{inc.desc}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Logs */}
              <div className="h-32 overflow-y-auto font-mono text-[10px] bg-zinc-950 text-emerald-400 p-3 rounded-xl border border-zinc-800 space-y-1">
                {incLogs.map((log, idx) => (
                  <div key={idx} className="leading-relaxed">{log}</div>
                ))}
                {incLogs.length === 0 && <span className="text-zinc-500">// Configure and launch increments.</span>}
              </div>
            </div>
          </div>

          {feedback && (
            <div className={`mt-5 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl flex items-start gap-3 ${complete ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-900 dark:text-emerald-300" : "bg-red-50 dark:bg-red-950/20 text-red-900 dark:text-red-300"}`}>
              {complete ? <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" /> : <XCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />}
              <div>
                <span className="font-bold text-xs uppercase block">SIMULATION REPORT</span>
                <p className="text-xs font-medium mt-1 leading-relaxed">{feedback}</p>
              </div>
            </div>
          )}
        </div>
      )}


      {/* 3. PROTOTYPE SIMULATOR */}
      {moduleId === "prototype" && (
        <div className="p-5 md:p-6 bg-white dark:bg-zinc-900 border-2 border-zinc-900 dark:border-zinc-700 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] rounded-2xl text-zinc-900 dark:text-zinc-100" id="modelling_game">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b-2 border-zinc-900 dark:border-zinc-700 pb-4 mb-4">
            <div>
              <h3 className="text-lg md:text-xl font-black uppercase tracking-tight text-indigo-600 dark:text-yellow-400">🎨 Discardable Prototyping Loop</h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">Construct mockup models and conduct rapid user focus group tests.</p>
            </div>
            <button onClick={resetPrototype} className="p-2 bg-zinc-100 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl hover:bg-zinc-200 cursor-pointer self-start md:self-auto shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-mono text-xs font-bold">
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>

          {protoScreen === "menu" && (
            <div className="text-center py-6 space-y-4">
              <span className="text-4xl">💭</span>
              <h4 className="font-bold text-base">Client has extremely vague web requirements.</h4>
              <p className="text-xs text-zinc-500 max-w-md mx-auto leading-relaxed">
                They want a mobile platform, but cannot describe features. We must build a rapid throwaway prototype model to map requirements cheap.
              </p>
              <button 
                onClick={() => setProtoScreen("building")}
                className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs uppercase rounded-xl border-2 border-zinc-900 dark:border-zinc-700 cursor-pointer shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]"
              >
                Launch Mock Design Editor
              </button>
            </div>
          )}

          {protoScreen === "building" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4 border-2 border-zinc-900 dark:border-zinc-700 p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/80">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-[10px] font-bold font-mono text-zinc-500 tracking-widest uppercase block">MOCK BUILDER (ITERATION {protoIteration})</span>
                  <span className="text-[10px] font-bold text-indigo-600">{protoFeatures.length}/3 features selected</span>
                </div>
                
                <div className="space-y-2">
                  {availableProtoFeatures.map(f => {
                    const isSelected = protoFeatures.includes(f.id);
                    return (
                      <button
                        key={f.id}
                        onClick={() => handleToggleFeature(f.id)}
                        className={`w-full p-3 border-2 rounded-xl text-left text-xs font-bold transition flex items-center justify-between cursor-pointer ${
                          isSelected 
                            ? "bg-yellow-200 border-zinc-900 text-zinc-950 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]" 
                            : "bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50"
                        }`}
                      >
                        <span>{f.label}</span>
                        {isSelected && <Check className="h-4 w-4" />}
                      </button>
                    );
                  })}
                </div>

                <button
                  onClick={handleTestPrototype}
                  disabled={protoFeatures.length === 0}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs uppercase rounded-xl border-2 border-zinc-900 dark:border-zinc-700 cursor-pointer shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] disabled:opacity-40"
                >
                  🚀 Push Mockup to User Testing
                </button>
              </div>

              <div className="border-2 border-zinc-900 dark:border-zinc-700 p-4 rounded-xl flex flex-col justify-center items-center text-center space-y-3 bg-zinc-100 dark:bg-zinc-850">
                <span className="text-3xl">📱</span>
                <span className="text-xs font-bold font-mono text-zinc-400 uppercase">Interactive Mock Sandbox</span>
                <div className="w-56 h-80 bg-zinc-900 border-4 border-zinc-950 rounded-[2rem] p-4 flex flex-col relative overflow-hidden text-zinc-100">
                  <div className="w-20 h-4 bg-zinc-950 mx-auto rounded-full mb-4"></div>
                  <div className="flex-1 space-y-2 text-left">
                    <span className="text-[10px] font-bold text-zinc-500 block uppercase font-mono">My prototype v{protoIteration}</span>
                    <div className="h-2 bg-zinc-800 rounded w-2/3"></div>
                    <div className="h-2 bg-zinc-800 rounded w-1/2"></div>
                    
                    <div className="mt-6 space-y-1.5 pt-4">
                      {protoFeatures.length === 0 ? (
                        <div className="text-[9px] text-zinc-500 text-center italic mt-6">Select wireframe modules on the left to inspect mobile simulation.</div>
                      ) : (
                        protoFeatures.map(f => {
                          const match = availableProtoFeatures.find(x => x.id === f);
                          return (
                            <div key={f} className="p-1.5 bg-zinc-800 border border-zinc-700 rounded text-[9px] font-bold truncate">
                              {match?.label}
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {protoScreen === "testing" && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border-2 border-zinc-900 dark:border-zinc-700 p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/80">
                  <span className="text-[10px] font-bold font-mono text-zinc-500 tracking-widest uppercase block mb-3">USER FOCUS GROUP REVIEWS</span>
                  <div className="space-y-3">
                    {protoFeedback.map((q, idx) => (
                      <div key={idx} className="p-2 bg-white dark:bg-zinc-900 border-2 border-zinc-200 dark:border-zinc-800 rounded-xl text-xs font-medium italic">
                        {q}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border-2 border-zinc-900 dark:border-zinc-700 p-4 rounded-xl flex flex-col justify-between bg-zinc-50 dark:bg-zinc-800/80 text-center">
                  <div>
                    <span className="text-[10px] font-bold font-mono text-zinc-500 tracking-widest uppercase block mb-3">REQUIREMENTS ACCURACY</span>
                    <div className="text-4xl md:text-5xl font-black font-mono text-indigo-600 dark:text-yellow-400">{protoFit}%</div>
                    <span className="text-[10px] font-medium text-zinc-500 block mt-1">Goal: Reach at least 75% for production sign-off.</span>
                  </div>

                  <div className="flex gap-3 justify-center mt-6">
                    <button 
                      onClick={iteratePrototype}
                      className="px-4 py-2 bg-white dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 text-xs font-bold uppercase rounded-xl hover:bg-zinc-55 hover:translate-x-[1px] hover:translate-y-[1px] cursor-pointer shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                    >
                      🔄 Design Next Prototype
                    </button>
                    <button 
                      onClick={submitProductionBuild}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black uppercase rounded-xl border-2 border-zinc-900 dark:border-zinc-700 cursor-pointer shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                    >
                      🚀 Commit Production Code
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {feedback && (
            <div className={`mt-5 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl flex items-start gap-3 ${complete ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-900 dark:text-emerald-300" : "bg-red-50 dark:bg-red-950/20 text-red-900 dark:text-red-300"}`}>
              {complete ? <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" /> : <XCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />}
              <div>
                <span className="font-bold text-xs uppercase block">SIMULATION REPORT</span>
                <p className="text-xs font-medium mt-1 leading-relaxed">{feedback}</p>
              </div>
            </div>
          )}
        </div>
      )}


      {/* 4. V-MODEL SYMMETRICAL PUZZLE */}
      {moduleId === "vmodel" && (
        <div className="p-5 md:p-6 bg-white dark:bg-zinc-900 border-2 border-zinc-900 dark:border-zinc-700 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] rounded-2xl text-zinc-900 dark:text-zinc-100" id="knowledge_game">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b-2 border-zinc-900 dark:border-zinc-700 pb-4 mb-4">
            <div>
              <h3 className="text-lg md:text-xl font-black uppercase tracking-tight text-indigo-600 dark:text-yellow-400">✌️ Symmetrical V-Model Connector</h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">Map development stages horizontally to their matching verification test suites.</p>
            </div>
            <button onClick={resetVModel} className="p-2 bg-zinc-100 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl hover:bg-zinc-200 cursor-pointer self-start md:self-auto shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-mono text-xs font-bold">
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative p-2">
            {/* Dev Column */}
            <div className="space-y-3">
              <span className="text-[10px] font-black font-mono text-indigo-600 dark:text-indigo-400 tracking-widest uppercase block mb-2">▼ DESIGN STAGE (LEFT LEG)</span>
              {devStages.map(d => {
                const isSelected = selectedDev === d.id;
                const isConnected = !!connections[d.id];
                return (
                  <button
                    key={d.id}
                    onClick={() => !isConnected && handleDevClick(d.id)}
                    className={`w-full p-3.5 border-2 rounded-xl text-left text-xs font-black transition cursor-pointer flex items-center justify-between ${
                      isConnected 
                        ? "bg-emerald-50 dark:bg-emerald-950/20 border-emerald-500 text-emerald-800 dark:text-emerald-400" 
                        : isSelected 
                          ? "bg-yellow-200 border-zinc-900 text-zinc-950 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] translate-x-1" 
                          : "bg-white dark:bg-zinc-900 border-zinc-350 dark:border-zinc-800 hover:bg-zinc-50"
                    }`}
                  >
                    <span>{d.label}</span>
                    {isConnected && <CheckCircle2 className="h-4 w-4 text-emerald-500" />}
                  </button>
                );
              })}
            </div>

            {/* Test Column */}
            <div className="space-y-3">
              <span className="text-[10px] font-black font-mono text-red-600 dark:text-red-400 tracking-widest uppercase block mb-2">▲ VERIFICATION TIER (RIGHT LEG)</span>
              {testStages.map(t => {
                const isMatched = Object.values(connections).includes(t.id);
                return (
                  <button
                    key={t.id}
                    onClick={() => !isMatched && handleTestClick(t.id, t.pairsWith)}
                    className={`w-full p-3.5 border-2 rounded-xl text-left text-xs font-black transition cursor-pointer flex items-center justify-between ${
                      isMatched 
                        ? "bg-emerald-50 dark:bg-emerald-950/20 border-emerald-500 text-emerald-800 dark:text-emerald-400" 
                        : "bg-white dark:bg-zinc-900 border-zinc-350 dark:border-zinc-800 hover:bg-zinc-50"
                    }`}
                  >
                    <span>{t.label}</span>
                    {isMatched && <CheckCircle2 className="h-4 w-4 text-emerald-500" />}
                  </button>
                );
              })}
            </div>
          </div>

          {vFeedback && (
            <div className="mt-4 p-3 bg-zinc-50 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 text-xs font-bold rounded-xl text-center">
              {vFeedback}
            </div>
          )}

          {feedback && (
            <div className="mt-5 p-4 border-2 border-emerald-500 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-900 dark:text-emerald-300 rounded-xl flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-xs uppercase block">SYMMETRIC PROOFS COMPLETE</span>
                <p className="text-xs font-medium mt-1 leading-relaxed">{feedback}</p>
              </div>
            </div>
          )}
        </div>
      )}


      {/* 5. SPIRAL RISK-MITIGATION LOOP */}
      {moduleId === "spiral" && (
        <div className="p-5 md:p-6 bg-white dark:bg-zinc-900 border-2 border-zinc-900 dark:border-zinc-700 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] rounded-2xl text-zinc-900 dark:text-zinc-100" id="rationale_game">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b-2 border-zinc-900 dark:border-zinc-700 pb-4 mb-4">
            <div>
              <h3 className="text-lg md:text-xl font-black uppercase tracking-tight text-indigo-600 dark:text-yellow-400">🌀 Spiral Risk Mitigation Spiral</h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">Loop iteratively to analyze risks before committing heavy dev capital.</p>
            </div>
            <button onClick={resetSpiral} className="p-2 bg-zinc-100 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl hover:bg-zinc-200 cursor-pointer self-start md:self-auto shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-mono text-xs font-bold">
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Controls */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-zinc-50 dark:bg-zinc-800/50 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-bold font-mono text-indigo-600 dark:text-indigo-400 tracking-widest uppercase">SPIRAL STATISTICS</span>
                  <span className="text-[10px] font-bold bg-zinc-900 text-white px-2 py-0.5 rounded font-mono">LOOP {spiralLoop} / 3</span>
                </div>

                <div className="p-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl flex items-center justify-between">
                  <span className="text-xs font-bold">Mitigation Budget:</span>
                  <span className="text-sm font-black text-indigo-600 font-mono">${spiralBudget.toLocaleString()}</span>
                </div>

                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-zinc-500 block">SELECT LOOP {spiralLoop} ACTIONS</span>
                  {availableMitigations.map(m => {
                    const isSelected = mitigationsSelected.includes(m.id);
                    return (
                      <button
                        key={m.id}
                        onClick={() => handleApplyMitigation(m.id, m.cost, m.targets)}
                        disabled={isSelected || spiralBudget < m.cost}
                        className={`w-full p-2.5 border-2 text-left text-xs font-bold rounded-xl transition cursor-pointer flex justify-between items-center ${
                          isSelected 
                            ? "bg-zinc-200 dark:bg-zinc-800 border-zinc-400 text-zinc-500" 
                            : "bg-white dark:bg-zinc-900 border-zinc-250 dark:border-zinc-750 hover:bg-zinc-50"
                        }`}
                      >
                        <span>{m.label}</span>
                        {isSelected && <Check className="h-4 w-4 text-zinc-500" />}
                      </button>
                    );
                  })}
                </div>

                <button
                  onClick={proceedSpiralLoop}
                  className="w-full py-2 bg-zinc-900 dark:bg-zinc-700 hover:bg-zinc-850 dark:hover:bg-zinc-600 text-white font-extrabold text-xs uppercase rounded-xl cursor-pointer flex items-center justify-center gap-2 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                >
                  🌀 Complete Loop {spiralLoop} & Plan Next <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

            {/* Logs & Visual Spiral representation */}
            <div className="lg:col-span-7 space-y-4">
              <div className="border-2 border-zinc-900 dark:border-zinc-700 p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/80 space-y-4">
                <span className="text-[10px] font-bold font-mono text-zinc-500 tracking-widest uppercase block">ACTIVE STRUCTURAL RISKS</span>
                
                <div className="space-y-2">
                  {spiralRisks.map(r => (
                    <div key={r} className="p-2.5 bg-red-50 dark:bg-red-950/20 border-2 border-red-500 text-red-800 dark:text-red-400 rounded-xl text-xs font-bold flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4 text-red-500 shrink-0" />
                      <span>{r}</span>
                    </div>
                  ))}
                  {spiralRisks.length === 0 && (
                    <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-500 text-emerald-800 dark:text-emerald-400 rounded-xl text-xs font-extrabold text-center flex items-center justify-center gap-2">
                      <ShieldCheck className="h-5 w-5 text-emerald-500" />
                      <span>Zero risks remaining! Ready for final software cutover.</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Logs */}
              <div className="h-32 overflow-y-auto font-mono text-[10px] bg-zinc-950 text-emerald-400 p-3 rounded-xl border border-zinc-800 space-y-1">
                {spiralLogs.map((log, idx) => (
                  <div key={idx} className="leading-relaxed">{log}</div>
                ))}
                {spiralLogs.length === 0 && <span className="text-zinc-500">// Run risk analysis mitigations above.</span>}
              </div>
            </div>
          </div>

          {feedback && (
            <div className={`mt-5 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl flex items-start gap-3 ${complete ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-900 dark:text-emerald-300" : "bg-red-50 dark:bg-red-950/20 text-red-900 dark:text-red-300"}`}>
              {complete ? <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" /> : <XCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />}
              <div>
                <span className="font-bold text-xs uppercase block">SIMULATION REPORT</span>
                <p className="text-xs font-medium mt-1 leading-relaxed">{feedback}</p>
              </div>
            </div>
          )}
        </div>
      )}


      {/* 6. RAPID APPLICATION DEVELOPMENT (RAD) */}
      {moduleId === "rapid" && (
        <div className="p-5 md:p-6 bg-white dark:bg-zinc-900 border-2 border-zinc-900 dark:border-zinc-700 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] rounded-2xl text-zinc-900 dark:text-zinc-100" id="umbrella_game">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b-2 border-zinc-900 dark:border-zinc-700 pb-4 mb-4">
            <div>
              <h3 className="text-lg md:text-xl font-black uppercase tracking-tight text-indigo-600 dark:text-yellow-400">⚡ High-Speed RAD Builder</h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">Accelerate timeline to 90 days using reusable libraries and JAD user sessions.</p>
            </div>
            <button onClick={resetRad} className="p-2 bg-zinc-100 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl hover:bg-zinc-200 cursor-pointer self-start md:self-auto shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-mono text-xs font-bold">
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-zinc-50 dark:bg-zinc-800/50 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl space-y-4">
                <span className="text-[10px] font-bold font-mono text-indigo-600 dark:text-indigo-400 tracking-widest uppercase block">SPEED RUN SETTINGS</span>
                
                <div>
                  <div className="flex justify-between text-xs font-bold mb-1">
                    <span className="flex items-center gap-1"><Layers className="h-3.5 w-3.5" /> Component Reusability</span>
                    <span className="font-mono text-indigo-600 dark:text-yellow-400">{radReuse}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="10" 
                    max="100" 
                    disabled={isPlaying}
                    value={radReuse} 
                    onChange={(e) => setRadReuse(parseInt(e.target.value))}
                    className="w-full accent-indigo-600 cursor-pointer"
                  />
                  <p className="text-[10px] text-zinc-500 mt-1">Saves massive coding hours through layout templates.</p>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-bold mb-1">
                    <span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" /> JAD Workshop Engagement</span>
                    <span className="font-mono text-indigo-600 dark:text-yellow-400">{radJad}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="10" 
                    max="100" 
                    disabled={isPlaying}
                    value={radJad} 
                    onChange={(e) => setRadJad(parseInt(e.target.value))}
                    className="w-full accent-indigo-600 cursor-pointer"
                  />
                  <p className="text-[10px] text-zinc-500 mt-1">Measures user participation in design feedback loops.</p>
                </div>

                <button 
                  onClick={runRadSimulation}
                  disabled={isPlaying}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs uppercase rounded-xl border-2 border-zinc-900 dark:border-zinc-700 cursor-pointer shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] disabled:opacity-40"
                >
                  {isPlaying ? "⚡ Compiling fast blocks..." : "▶ Start 90-Day Sprint"}
                </button>
              </div>
            </div>

            <div className="lg:col-span-7 space-y-4">
              {/* Day countdown Visual */}
              <div className="border-2 border-zinc-900 dark:border-zinc-700 p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/80 text-center flex flex-col justify-center items-center py-6">
                <span className="text-[10px] font-bold font-mono text-zinc-500 tracking-widest uppercase block mb-2">90-DAY CUTOVER TIMEBOX TIMER</span>
                <div className="text-5xl font-black font-mono text-indigo-600 dark:text-yellow-400 flex items-center gap-1">
                  <Clock className="h-8 w-8 animate-spin" /> {radDay} Days
                </div>
                <div className="w-full bg-zinc-200 dark:bg-zinc-700 h-2.5 rounded-full border border-zinc-900 mt-4 overflow-hidden">
                  <div className="bg-indigo-600 h-full rounded-full transition-all duration-150" style={{ width: `${(radDay / 90) * 100}%` }}></div>
                </div>
              </div>

              {/* Logs */}
              <div className="h-32 overflow-y-auto font-mono text-[10px] bg-zinc-950 text-emerald-400 p-3 rounded-xl border border-zinc-800 space-y-1">
                {radLogs.map((log, idx) => (
                  <div key={idx} className="leading-relaxed">{log}</div>
                ))}
                {radLogs.length === 0 && <span className="text-zinc-500">// Adjust sliders and run speedrun.</span>}
              </div>
            </div>
          </div>

          {feedback && (
            <div className={`mt-5 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl flex items-start gap-3 ${radStatus === "success" ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-900 dark:text-emerald-300" : "bg-red-50 dark:bg-red-950/20 text-red-900 dark:text-red-300"}`}>
              {radStatus === "success" ? <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" /> : <XCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />}
              <div>
                <span className="font-bold text-xs uppercase block">SIMULATION REPORT</span>
                <p className="text-xs font-medium mt-1 leading-relaxed">{feedback}</p>
              </div>
            </div>
          )}
        </div>
      )}


      {/* 7. AGILE SIMULATOR */}
      {moduleId === "agile" && (
        <div className="p-5 md:p-6 bg-white dark:bg-zinc-900 border-2 border-zinc-900 dark:border-zinc-700 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] rounded-2xl text-zinc-900 dark:text-zinc-100" id="challenges_game">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b-2 border-zinc-900 dark:border-zinc-700 pb-4 mb-4">
            <div>
              <h3 className="text-lg md:text-xl font-black uppercase tracking-tight text-indigo-600 dark:text-yellow-400">🏃 Agile Scrum Kanban Board</h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">Sprint collaboratively through backlogs to deliver continuous value increments.</p>
            </div>
            <button onClick={resetAgile} className="p-2 bg-zinc-100 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl hover:bg-zinc-200 cursor-pointer self-start md:self-auto shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-mono text-xs font-bold">
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-4 space-y-4">
              <div className="bg-zinc-50 dark:bg-zinc-800/50 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl space-y-4">
                <span className="text-[10px] font-bold font-mono text-indigo-600 dark:text-indigo-400 tracking-widest uppercase block">TEAM CAPABILITY</span>
                
                <div>
                  <div className="flex justify-between text-xs font-bold mb-1">
                    <span className="flex items-center gap-1"><Sparkles className="h-3.5 w-3.5 text-yellow-500" /> Sprint Velocity</span>
                    <span className="font-mono text-indigo-600 dark:text-yellow-400">{agileVelocity} story points</span>
                  </div>
                  <input 
                    type="range" 
                    min="5" 
                    max="25" 
                    disabled={isPlaying}
                    value={agileVelocity} 
                    onChange={(e) => setAgileVelocity(parseInt(e.target.value))}
                    className="w-full accent-indigo-600 cursor-pointer"
                  />
                  <p className="text-[10px] text-zinc-500 mt-1">Cumulative points your engineering squad can clear per sprint.</p>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-bold mb-1">
                    <span className="flex items-center gap-1"><AlertTriangle className="h-3.5 w-3.5 text-red-500" /> Scope Creep/Bloat</span>
                    <span className="font-mono text-red-500">{agileScope}% complexity penalty</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="20" 
                    disabled={isPlaying}
                    value={agileScope} 
                    onChange={(e) => setAgileScope(parseInt(e.target.value))}
                    className="w-full accent-red-500 cursor-pointer"
                  />
                  <p className="text-[10px] text-zinc-500 mt-1">Ad-hoc demands from sales that drag down developer focus.</p>
                </div>

                <button 
                  onClick={runSprintCycle}
                  disabled={isPlaying}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs uppercase rounded-xl border-2 border-zinc-900 dark:border-zinc-700 cursor-pointer shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] disabled:opacity-40"
                >
                  {isPlaying ? "🏃 Executing Daily Standup..." : `▶ Commit Sprint ${agileSprint}`}
                </button>
              </div>
            </div>

            {/* Kanban columns */}
            <div className="lg:col-span-8 space-y-4">
              <div className="grid grid-cols-4 gap-2.5">
                {[
                  { id: "backlog", title: "Backlog", bg: "bg-zinc-100 text-zinc-500 border-zinc-350" },
                  { id: "progress", title: "Coding", bg: "bg-blue-50 text-blue-750 border-blue-400" },
                  { id: "review", title: "PR Review", bg: "bg-yellow-50 text-yellow-750 border-yellow-400" },
                  { id: "done", title: "Done ✨", bg: "bg-emerald-50 text-emerald-850 border-emerald-400" }
                ].map(col => {
                  const tasks = kanbanTasks.filter(t => t.col === col.id);
                  return (
                    <div key={col.id} className={`p-2 border-2 rounded-xl flex flex-col min-h-[12rem] bg-zinc-50 dark:bg-zinc-800/40`}>
                      <span className="text-[9px] font-black uppercase text-center block mb-2 font-mono tracking-tight">{col.title} ({tasks.length})</span>
                      <div className="space-y-1.5 flex-1">
                        {tasks.map(t => (
                          <div key={t.id} className="p-1.5 bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-800 rounded-lg shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] text-[9px] font-bold leading-tight">
                            <span className="block truncate">{t.title}</span>
                            <span className="text-[8px] font-mono font-bold text-zinc-400 block mt-1">Points: {t.pts}</span>
                          </div>
                        ))}
                        {tasks.length === 0 && <span className="text-[8px] text-zinc-400 italic text-center block mt-8">Empty</span>}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Logs */}
              <div className="h-28 overflow-y-auto font-mono text-[10px] bg-zinc-950 text-emerald-400 p-3 rounded-xl border border-zinc-800 space-y-1">
                {agileLogs.map((log, idx) => (
                  <div key={idx} className="leading-relaxed">{log}</div>
                ))}
                {agileLogs.length === 0 && <span className="text-zinc-500">// Hit commit sprint to run iteration workflow.</span>}
              </div>
            </div>
          </div>

          {feedback && (
            <div className={`mt-5 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl flex items-start gap-3 ${complete ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-900 dark:text-emerald-300" : "bg-red-50 dark:bg-red-950/20 text-red-900 dark:text-red-300"}`}>
              {complete ? <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" /> : <XCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />}
              <div>
                <span className="font-bold text-xs uppercase block">SIMULATION REPORT</span>
                <p className="text-xs font-medium mt-1 leading-relaxed">{feedback}</p>
              </div>
            </div>
          )}
        </div>
      )}


      {/* 8. DBMS SIMULATOR */}
      {moduleId === "dbms" && (
        <div className="p-5 md:p-6 bg-white dark:bg-zinc-900 border-2 border-zinc-900 dark:border-zinc-700 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] rounded-2xl text-zinc-900 dark:text-zinc-100" id="dbms_game">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b-2 border-zinc-900 dark:border-zinc-700 pb-4 mb-4">
            <div>
              <h3 className="text-lg md:text-xl font-black uppercase tracking-tight text-indigo-600 dark:text-yellow-400">🗄️ Relational DBMS Sandbox</h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">Simulate interactive SQL operations, indexing efficiency, and ACID lock transactions.</p>
            </div>
            <button onClick={resetDbSimulator} className="p-2 bg-zinc-100 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl hover:bg-zinc-200 cursor-pointer self-start md:self-auto shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-mono text-xs font-bold">
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>

          {/* Core Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Control center & Tabs */}
            <div className="lg:col-span-4 space-y-4">
              <div className="bg-zinc-50 dark:bg-zinc-800/40 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl space-y-3">
                <span className="text-[10px] font-bold font-mono text-indigo-600 dark:text-indigo-400 tracking-widest uppercase block">SANDBOX OPERATIONS</span>
                
                <div className="flex flex-col gap-2">
                  {[
                    { id: "table", label: "📊 RELATION TABLE" },
                    { id: "insert", label: "📥 INSERT RECORD" },
                    { id: "search", label: "🔍 INDEX LOOKUP" },
                    { id: "acid", label: "🔒 ACID CONCURRENCY" }
                  ].map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setDbActiveTab(tab.id as any)}
                      className={`w-full p-2.5 rounded-lg text-left text-xs font-black border-2 transition duration-150 cursor-pointer select-none ${
                        dbActiveTab === tab.id
                          ? "bg-yellow-300 dark:bg-yellow-400 text-zinc-950 border-zinc-900 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] translate-x-[-1px] translate-y-[-1px]"
                          : "bg-white dark:bg-zinc-900 border-zinc-250 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-50"
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Transaction engine console */}
              <div className="bg-zinc-950 text-emerald-400 p-4 rounded-xl border-2 border-zinc-900 font-mono text-[10px] space-y-1 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <div className="flex justify-between border-b border-zinc-800 pb-1.5 mb-2 text-[9px] text-zinc-500 font-bold uppercase tracking-wider select-none">
                  <span>📜 TRANSACTIONS LOG TERMINAL</span>
                  <span className="animate-pulse text-emerald-500">● ENGINE ONLINE</span>
                </div>
                <div className="h-36 overflow-y-auto scrollbar-thin space-y-1">
                  {dbLogs.map((log, idx) => (
                    <div key={idx} className="leading-relaxed whitespace-pre-wrap">{log}</div>
                  ))}
                </div>
              </div>
            </div>

            {/* Simulated Workspace */}
            <div className="lg:col-span-8 bg-zinc-50 dark:bg-zinc-805 border-2 border-zinc-900 dark:border-zinc-700 p-5 rounded-xl min-h-[25rem] flex flex-col justify-between">
              
              <AnimatePresence mode="wait">
                {/* 8a. RELATION TABLE VIEW */}
                {dbActiveTab === "table" && (
                  <motion.div
                    key="table"
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="space-y-4"
                  >
                    <div>
                      <span className="text-[10px] font-bold font-mono text-zinc-400 tracking-wider block uppercase select-none">DATABASE RELATION STATE</span>
                      <h4 className="text-sm font-black uppercase text-zinc-900 dark:text-white mt-1 select-none">Relation: Students</h4>
                      <p className="text-[11px] text-zinc-500 mt-1 select-none">Underlying disk relation. Delete rows to trigger instant relational delete SQL statements.</p>
                    </div>

                    <div className="overflow-x-auto border-2 border-zinc-900 dark:border-zinc-700 rounded-xl bg-white dark:bg-zinc-900 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="bg-zinc-100 dark:bg-zinc-800 text-zinc-750 dark:text-zinc-300 border-b-2 border-zinc-900 dark:border-zinc-700 font-black font-mono">
                            <th className="p-2.5 border-r border-zinc-900 dark:border-zinc-700">rollNo (PK)</th>
                            <th className="p-2.5 border-r border-zinc-900 dark:border-zinc-700">name</th>
                            <th className="p-2.5 border-r border-zinc-900 dark:border-zinc-700">branch</th>
                            <th className="p-2.5 border-r border-zinc-900 dark:border-zinc-700">attendance</th>
                            <th className="p-2.5 text-center">action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {dbRecords.map((r, i) => (
                            <tr key={r.rollNo} className="border-b border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-800/50">
                              <td className="p-2.5 font-mono font-black text-indigo-600 dark:text-yellow-400 border-r border-zinc-200 dark:border-zinc-800">{r.rollNo}</td>
                              <td className="p-2.5 font-bold border-r border-zinc-200 dark:border-zinc-800 text-zinc-800 dark:text-zinc-200">{r.name}</td>
                              <td className="p-2.5 border-r border-zinc-200 dark:border-zinc-800">
                                <span className="bg-zinc-100 dark:bg-zinc-800 text-zinc-650 px-1.5 py-0.5 rounded font-mono text-[10px] font-bold">{r.branch}</span>
                              </td>
                              <td className="p-2.5 border-r border-zinc-200 dark:border-zinc-800 font-mono font-bold">
                                <span className={r.attendance >= 85 ? "text-emerald-600" : r.attendance >= 75 ? "text-amber-600" : "text-red-500"}>
                                  {r.attendance}%
                                </span>
                              </td>
                              <td className="p-2.5 text-center">
                                <button
                                  onClick={() => handleDbDelete(r.rollNo)}
                                  className="p-1 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 border border-transparent hover:border-red-300 rounded cursor-pointer transition"
                                  title="Delete record from disk"
                                >
                                  <XCircle className="h-4 w-4" />
                                </button>
                              </td>
                            </tr>
                          ))}
                          {dbRecords.length === 0 && (
                            <tr>
                              <td colSpan={5} className="p-8 text-center text-zinc-400 font-bold italic font-mono">// Relation Students is empty. Go to 'Insert' tab to add rows!</td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>

                    <div className="text-[11px] text-zinc-500 font-mono flex items-center gap-1">
                      <span>💡 Current database size: </span>
                      <strong className="text-zinc-900 dark:text-white">{dbRecords.length} record(s)</strong>
                      <span>(Aim to grow relation to 4+ records using Insert tab to clear simulation)</span>
                    </div>
                  </motion.div>
                )}

                {/* 8b. INSERT RECORD FORM */}
                {dbActiveTab === "insert" && (
                  <motion.div
                    key="insert"
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="space-y-4"
                  >
                    <div>
                      <span className="text-[10px] font-bold font-mono text-indigo-500 tracking-wider block uppercase select-none">INSERT ROW INTERFACE</span>
                      <h4 className="text-sm font-black uppercase text-zinc-900 dark:text-white mt-1 select-none">Perform INSERT statement</h4>
                      <p className="text-[11px] text-zinc-500 mt-1 select-none">Enter data below. The DBMS will automatically validate the **Primary Key constraint** before writing to database pages.</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white dark:bg-zinc-900 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                      <div className="space-y-3">
                        <div>
                          <label className="block text-[10px] font-mono font-black uppercase text-zinc-500 dark:text-zinc-400 mb-1">Roll Number (Primary Key)</label>
                          <input
                            type="number"
                            placeholder="e.g. 104"
                            value={dbInsRollNo}
                            onChange={(e) => setDbInsRollNo(e.target.value)}
                            className="w-full p-2 text-xs bg-zinc-50 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-lg text-zinc-900 dark:text-zinc-100 font-mono font-bold focus:outline-none focus:border-indigo-500"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-mono font-black uppercase text-zinc-500 dark:text-zinc-400 mb-1">Student Name</label>
                          <input
                            type="text"
                            placeholder="e.g. Rohini Aruna"
                            value={dbInsName}
                            onChange={(e) => setDbInsName(e.target.value)}
                            className="w-full p-2 text-xs bg-zinc-50 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-lg text-zinc-900 dark:text-zinc-100 font-bold focus:outline-none focus:border-indigo-500"
                          />
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <label className="block text-[10px] font-mono font-black uppercase text-zinc-500 dark:text-zinc-400 mb-1">Branch/Department</label>
                          <select
                            value={dbInsBranch}
                            onChange={(e) => setDbInsBranch(e.target.value)}
                            className="w-full p-2 text-xs bg-zinc-50 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-lg text-zinc-900 dark:text-zinc-100 font-bold focus:outline-none focus:border-indigo-500"
                          >
                            <option value="CSE">CSE (Computer Science)</option>
                            <option value="ECE">ECE (Electronics)</option>
                            <option value="MECH">MECH (Mechanical)</option>
                            <option value="CIVIL">CIVIL (Civil)</option>
                          </select>
                        </div>

                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <label className="block text-[10px] font-mono font-black uppercase text-zinc-500 dark:text-zinc-400">Attendance Percentage</label>
                            <span className="font-mono text-xs font-bold text-indigo-600 dark:text-yellow-400">{dbInsAttendance}%</span>
                          </div>
                          <input
                            type="range"
                            min="40"
                            max="100"
                            value={dbInsAttendance}
                            onChange={(e) => setDbInsAttendance(parseInt(e.target.value))}
                            className="w-full accent-indigo-600 cursor-pointer"
                          />
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={handleDbInsert}
                      className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs uppercase rounded-xl border-2 border-zinc-900 dark:border-zinc-700 cursor-pointer shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] active:translate-y-[1px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                    >
                      ⚡ Execute INSERT INTO Students ...
                    </button>
                  </motion.div>
                )}

                {/* 8c. QUERY SEARCH WITH INDEX VS SEQUENTIAL SCAN */}
                {dbActiveTab === "search" && (
                  <motion.div
                    key="search"
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="space-y-4"
                  >
                    <div>
                      <span className="text-[10px] font-bold font-mono text-indigo-500 tracking-wider block uppercase select-none">INDEX VS SEQUENTIAL SCAN SANDBOX</span>
                      <h4 className="text-sm font-black uppercase text-zinc-900 dark:text-white mt-1 select-none">Select Query Execution Strategy</h4>
                      <p className="text-[11px] text-zinc-500 mt-1 select-none">See how database indexing avoids full sequential disk scan. Query with index takes **O(1)** instead of scanning every record sequentially **O(N)**!</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white dark:bg-zinc-900 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                      <div className="space-y-3 flex flex-col justify-between">
                        <div>
                          <label className="block text-[10px] font-mono font-black uppercase text-zinc-500 dark:text-zinc-400 mb-1.5">Query Scan Mode</label>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              onClick={() => setDbSearchMethod("sequential")}
                              className={`p-2 rounded text-[10px] font-bold border-2 transition ${
                                dbSearchMethod === "sequential"
                                  ? "bg-rose-100 dark:bg-rose-950/40 text-rose-950 dark:text-rose-450 border-rose-900 font-black shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
                                  : "bg-zinc-50 dark:bg-zinc-800 border-zinc-300 dark:border-zinc-700 text-zinc-500"
                              }`}
                            >
                              🐢 SEQUENTIAL SCAN
                            </button>
                            <button
                              onClick={() => setDbSearchMethod("indexed")}
                              className={`p-2 rounded text-[10px] font-bold border-2 transition ${
                                dbSearchMethod === "indexed"
                                  ? "bg-emerald-100 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-450 border-emerald-900 font-black shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
                                  : "bg-zinc-50 dark:bg-zinc-800 border-zinc-300 dark:border-zinc-700 text-zinc-500"
                              }`}
                            >
                              🚀 INDEXED B-TREE
                            </button>
                          </div>
                        </div>

                        <div>
                          <label className="block text-[10px] font-mono font-black uppercase text-zinc-500 dark:text-zinc-400 mb-1">Enter Roll Number to Find</label>
                          <div className="flex gap-2">
                            <input
                              type="number"
                              placeholder="e.g. 103"
                              value={dbSearchRollNo}
                              onChange={(e) => setDbSearchRollNo(e.target.value)}
                              className="w-full p-2 text-xs bg-zinc-50 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-lg text-zinc-900 dark:text-zinc-100 font-mono font-bold focus:outline-none"
                            />
                            <button
                              onClick={handleDbSearch}
                              className="px-4 bg-zinc-900 text-white dark:bg-zinc-800 hover:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-lg text-xs font-black cursor-pointer shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] flex items-center gap-1 shrink-0"
                            >
                              <Search className="h-3.5 w-3.5" /> SELECT
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Display Results */}
                      <div className="border border-dashed border-zinc-300 dark:border-zinc-800 p-3.5 rounded-xl bg-zinc-50 dark:bg-zinc-950/50 flex flex-col justify-between">
                        <span className="text-[9px] font-mono font-black text-zinc-400 uppercase tracking-wider block mb-2 select-none">EXECUTION SPECS RESULT</span>
                        
                        {dbSearchResult && dbSearchResult !== "not_found" && (
                          <div className="space-y-1">
                            <div className="text-[10px] font-bold text-emerald-600 uppercase flex items-center gap-1 select-none">
                              <Check className="h-3.5 w-3.5" /> RECORD RETRIEVED SECURELY
                            </div>
                            <div className="text-xs bg-white dark:bg-zinc-900 border-2 border-zinc-900 dark:border-zinc-700 p-2.5 rounded-lg space-y-1 font-mono text-[11px] shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]">
                              <div><span className="text-zinc-400">rollNo :</span> <strong className="text-indigo-600 dark:text-yellow-400 font-black">{dbSearchResult.rollNo}</strong></div>
                              <div><span className="text-zinc-400">name   :</span> <strong className="text-zinc-900 dark:text-white font-extrabold">{dbSearchResult.name}</strong></div>
                              <div><span className="text-zinc-400">branch :</span> <strong className="text-zinc-700 dark:text-zinc-300 font-bold">{dbSearchResult.branch}</strong></div>
                              <div><span className="text-zinc-400">attendance:</span> <strong className="text-zinc-750 dark:text-zinc-300 font-black">{dbSearchResult.attendance}%</strong></div>
                            </div>
                          </div>
                        )}

                        {dbSearchResult === "not_found" && (
                          <div className="text-xs text-red-500 font-mono font-bold py-2 bg-red-50 dark:bg-red-950/20 px-2.5 rounded border border-red-200">
                            ⚠️ SQL Exception: Empty result set. Roll Number not found in disk blocks.
                          </div>
                        )}

                        {!dbSearchResult && (
                          <div className="text-center py-6 text-xs text-zinc-400 italic font-mono select-none">
                            // Input student Roll Number and press SELECT to query database page.
                          </div>
                        )}

                        {dbSearchResult && (
                          <div className="mt-2 pt-2 border-t border-zinc-200 dark:border-zinc-800 grid grid-cols-2 gap-2 text-[10px] font-mono">
                            <div>
                              <span className="block text-zinc-400 font-bold">ALGORITHM:</span>
                              <span className="text-zinc-900 dark:text-white font-extrabold">{dbSearchMethod.toUpperCase()}</span>
                            </div>
                            <div>
                              <span className="block text-zinc-400 font-bold">DISK READ COST:</span>
                              <span className={`font-extrabold ${dbScanSteps <= 1 ? "text-emerald-600" : "text-rose-500"}`}>{dbScanSteps} block(s)</span>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* 8d. ACID CONCURRENCY SANDBOX */}
                {dbActiveTab === "acid" && (
                  <motion.div
                    key="acid"
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="space-y-4"
                  >
                    <div>
                      <span className="text-[10px] font-bold font-mono text-indigo-500 tracking-wider block uppercase select-none">ACID ISOLATION TRANSACTION SANDBOX</span>
                      <h4 className="text-sm font-black uppercase text-zinc-900 dark:text-white mt-1 select-none">Lost Update Anomaly Simulation</h4>
                      <p className="text-[11px] text-zinc-500 mt-1 select-none">Witness what happens when two transactions update Aruna's attendance concurrently. Turn on locking to prevent race conditions!</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                      {/* Configuration */}
                      <div className="md:col-span-5 bg-white dark:bg-zinc-900 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl flex flex-col justify-between gap-3 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                        <div>
                          <label className="block text-[10px] font-mono font-black uppercase text-zinc-500 dark:text-zinc-400 mb-2">Concurrency Setting</label>
                          <div className="flex items-center justify-between p-2.5 bg-zinc-50 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-lg">
                            <div>
                              <span className="text-xs font-black uppercase block">🔒 Ex Lock Control</span>
                              <span className="text-[9px] text-zinc-500 block">Prevent lost updates</span>
                            </div>
                            <input
                              type="checkbox"
                              checked={acidLockActive}
                              onChange={(e) => setAcidLockActive(e.target.checked)}
                              disabled={acidStatus === "running"}
                              className="w-4 h-4 cursor-pointer accent-indigo-600"
                            />
                          </div>
                        </div>

                        <div className="space-y-1">
                          <span className="text-[8px] font-mono font-bold text-zinc-400 block uppercase select-none">Initial Record state:</span>
                          <span className="text-xs font-black text-zinc-800 dark:text-zinc-200">Aruna Rohini: 92% Attendance</span>
                        </div>

                        <button
                          onClick={runAcidSimulation}
                          disabled={acidStatus === "running"}
                          className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase rounded-lg border-2 border-zinc-900 dark:border-zinc-700 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] disabled:opacity-50 select-none cursor-pointer"
                        >
                          {acidStatus === "running" ? "⏳ Transactions executing..." : "▶ Run Concurrently"}
                        </button>
                      </div>

                      {/* Live Transaction Terminal */}
                      <div className="md:col-span-7 bg-zinc-950 text-emerald-400 p-4 rounded-xl border-2 border-zinc-900 font-mono text-[10px] h-48 overflow-y-auto scrollbar-thin space-y-1 flex flex-col justify-between shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                        <div>
                          <span className="text-[8px] text-zinc-500 block border-b border-zinc-850 pb-1 mb-1.5 select-none">💾 TRANSACTION SCHEDULER MONITOR</span>
                          <div className="space-y-1">
                            {acidLog.map((line, idx) => (
                              <div key={idx} className="leading-relaxed">{line}</div>
                            ))}
                            {acidLog.length === 0 && <span className="text-zinc-500 italic">// Click 'Run Concurrently' to simulate transaction pipeline schedules.</span>}
                          </div>
                        </div>
                        {acidStatus !== "idle" && acidStatus !== "running" && (
                          <div className={`mt-2 p-1.5 border rounded text-[9px] font-black uppercase ${acidStatus === "success" ? "bg-emerald-950/40 text-emerald-400 border-emerald-800" : "bg-red-950/40 text-red-400 border-red-800"}`}>
                            {acidStatus === "success" ? "✅ ISOLATION SECURED: ACID STANDARDS COMPLIED" : "🚨 RACE CONDITION CAUGHT: DATA CORRUPTED (LOST UPDATE)"}
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Simulation Result / Trigger bar */}
              <div className="mt-4 pt-4 border-t-2 border-zinc-200 dark:border-zinc-700 flex justify-between items-center text-xs">
                <span className="font-mono text-[10px] text-zinc-400 font-bold select-none">// Relation: Students | Schema: Relational</span>
                <button
                  onClick={resetDbSimulator}
                  className="px-2.5 py-1.5 border border-zinc-300 dark:border-zinc-700 hover:border-zinc-900 text-[10px] font-mono font-bold uppercase rounded-lg bg-white dark:bg-zinc-800 text-zinc-500 hover:text-zinc-900 cursor-pointer"
                >
                  Reload Engine
                </button>
              </div>
            </div>
          </div>

          {/* Report Feedback */}
          {feedback && (
            <div className={`mt-5 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl flex items-start gap-3 ${complete ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-900 dark:text-emerald-300" : "bg-red-50 dark:bg-red-950/20 text-red-900 dark:text-red-300"}`}>
              {complete ? <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" /> : <XCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />}
              <div>
                <span className="font-bold text-xs uppercase block select-none">SIMULATION REPORT</span>
                <p className="text-xs font-medium mt-1 leading-relaxed">{feedback}</p>
              </div>
            </div>
          )}
        </div>
      )}

    </div>
  );
}
