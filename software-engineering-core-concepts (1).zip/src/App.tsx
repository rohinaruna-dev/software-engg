/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { 
  GraduationCap, Compass, RotateCcw, Menu, X, ArrowRight,
  Search, Moon, Sun, CheckCircle2, Trophy, HelpCircle
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { modulesData } from "./data/modulesData";
import ModuleContainer from "./components/ModuleContainer";
import { StudentProgress } from "./types";

export default function App() {
  const [activeModuleId, setActiveModuleId] = useState<string>("waterfall");
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    const saved = localStorage.getItem("app_theme");
    return (saved === "dark" || saved === "light") ? saved : "light";
  });
  
  // Universal Search states
  const [universalQuery, setUniversalQuery] = useState<string>("");
  const [universalResults, setUniversalResults] = useState<{ moduleId: string; title: string; text: string; section: string }[]>([]);

  // Initialize progress state from localStorage or defaults
  const [progress, setProgress] = useState<StudentProgress>(() => {
    const saved = localStorage.getItem("se_module_progress");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Clean up any stale modules from previous models if they exist
        const validIds = modulesData.map(m => m.id);
        return {
          completedModules: (parsed.completedModules || []).filter((id: string) => validIds.includes(id)),
          quizScores: parsed.quizScores || {}
        };
      } catch (e) {
        // Fallback
      }
    }
    return {
      completedModules: [],
      quizScores: {}
    };
  });

  // Sync theme to root DOM element
  useEffect(() => {
    localStorage.setItem("app_theme", theme);
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);

  // Persist progress changes
  useEffect(() => {
    localStorage.setItem("se_module_progress", JSON.stringify(progress));
  }, [progress]);

  // Universal Search logic
  useEffect(() => {
    if (!universalQuery.trim()) {
      setUniversalResults([]);
      return;
    }
    const query = universalQuery.toLowerCase();
    const results: typeof universalResults = [];

    modulesData.forEach(m => {
      // Check title or description
      if (m.title.toLowerCase().includes(query) || m.shortDescription.toLowerCase().includes(query)) {
        results.push({
          moduleId: m.id,
          title: m.title,
          text: m.shortDescription,
          section: "Process Model Overview"
        });
      }
      // Check detailed content sections
      m.detailedContent.forEach(sec => {
        if (sec.sectionTitle.toLowerCase().includes(query)) {
          results.push({
            moduleId: m.id,
            title: m.title,
            text: `Section: ${sec.sectionTitle}`,
            section: "Theory Section"
          });
        }
        sec.paragraphs.forEach(p => {
          if (p.toLowerCase().includes(query)) {
            const index = p.toLowerCase().indexOf(query);
            const excerpt = (index > 40 ? "..." : "") + p.substring(Math.max(0, index - 40), Math.min(p.length, index + 60)) + "...";
            results.push({
              moduleId: m.id,
              title: m.title,
              text: excerpt,
              section: "Detailed Paragraph"
            });
          }
        });
      });
      // Check relatable analogies
      m.relatableExamples.forEach(ex => {
        if (ex.title.toLowerCase().includes(query) || ex.scenario.toLowerCase().includes(query) || ex.analogy.toLowerCase().includes(query)) {
          results.push({
            moduleId: m.id,
            title: m.title,
            text: `Analogy: ${ex.title}`,
            section: "Analogy Case study"
          });
        }
      });
    });

    // Deduplicate or limit to top 5
    setUniversalResults(results.slice(0, 5));
  }, [universalQuery]);

  const handleUpdateProgress = (moduleId: string, quizScore: number) => {
    setProgress((prev) => {
      const completed = [...prev.completedModules];
      if (!completed.includes(moduleId)) {
        completed.push(moduleId);
      }

      const scores = { ...prev.quizScores } as Record<string, number>;
      const existingScore = scores[moduleId] ?? -1;
      if (quizScore > existingScore) {
        scores[moduleId] = quizScore;
      }

      return {
        completedModules: completed,
        quizScores: scores
      };
    });
  };

  const handleResetProgress = () => {
    if (window.confirm("Are you sure you want to reset all your study progress, simulation grades, and quiz scores?")) {
      const emptyProgress = { completedModules: [], quizScores: {} };
      setProgress(emptyProgress);
      localStorage.setItem("se_module_progress", JSON.stringify(emptyProgress));
      setActiveModuleId("waterfall");
    }
  };

  const activeModule = modulesData.find((m) => m.id === activeModuleId) || modulesData[0];
  const activeModuleIndex = modulesData.findIndex((m) => m.id === activeModuleId);
  const nextModule = activeModuleIndex !== -1 && activeModuleIndex < modulesData.length - 1 
    ? modulesData[activeModuleIndex + 1] 
    : null;
  const prevModule = activeModuleIndex > 0 
    ? modulesData[activeModuleIndex - 1] 
    : null;

  // Calculate statistics
  const totalCompleted = progress.completedModules.length;
  const progressPercent = Math.round((totalCompleted / modulesData.length) * 100);
  
  const quizScoresList = Object.values(progress.quizScores) as number[];
  const totalQuizzesPassed = quizScoresList.filter(score => score > 0).length;
  const averageAccuracy = quizScoresList.length > 0 
    ? Math.round((quizScoresList.reduce((sum, score) => sum + score, 0) / (quizScoresList.length * 2)) * 100)
    : 0;

  return (
    <div className={`min-h-screen font-sans flex flex-col antialiased p-4 md:p-6 lg:p-8 gap-5 transition-colors duration-200 ${
      theme === "dark" ? "bg-zinc-950 text-zinc-100" : "bg-zinc-100 text-zinc-900"
    }`}>
      
      {/* Top Navigation Frame Header - Bento Block */}
      <header className="bg-white dark:bg-zinc-900 border-2 border-zinc-900 dark:border-zinc-700 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] p-5 rounded-2xl flex flex-col xl:flex-row xl:items-center justify-between gap-4 z-40 relative">
        <div className="flex flex-col gap-1.5 flex-1 max-w-2xl">
          <span className="text-xs font-bold tracking-widest uppercase text-zinc-500 dark:text-zinc-400 flex items-center gap-2 select-none">
            <GraduationCap className="h-4 w-4 text-indigo-600 dark:text-yellow-400" /> University Computer Science & Engineering • Learning Suite
          </span>
          <h1 className="text-xl md:text-2.5xl font-black tracking-tighter text-zinc-900 dark:text-white uppercase italic flex items-center gap-2 select-none">
            Interactive CS Syllabus & Lab Sandbox Suite
          </h1>
          <p className="text-xs font-medium text-zinc-500 dark:text-zinc-450 select-none">SDLC Process Models & Database Management Systems (DBMS) // University Courseware</p>
        </div>

        {/* Global Controls Row: Search & Theme Toggle & Progress */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-4 flex-1 justify-end">
          
          {/* Universal Search bar */}
          <div className="relative flex-1 max-w-md">
            <div className="flex items-center bg-zinc-50 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl px-3 py-1.5 focus-within:ring-2 focus-within:ring-indigo-500 transition shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              <Search className="h-4 w-4 text-zinc-400 shrink-0 mr-2" />
              <input 
                type="text"
                placeholder="Universal Search across all syllabus topics..."
                value={universalQuery}
                onChange={(e) => setUniversalQuery(e.target.value)}
                className="bg-transparent border-none text-xs focus:outline-none w-full text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 dark:placeholder-zinc-500"
              />
              {universalQuery && (
                <button onClick={() => setUniversalQuery("")} className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200">
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            {/* Universal Search Dropdown */}
            <AnimatePresence>
              {universalResults.length > 0 && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute left-0 right-0 mt-2 bg-white dark:bg-zinc-900 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] overflow-hidden z-50 text-left p-2 space-y-1"
                >
                  <span className="text-[9px] font-black font-mono text-zinc-400 uppercase tracking-wider block p-1 border-b border-zinc-100 dark:border-zinc-800 mb-1">
                    🔍 Top Matches Found ({universalResults.length})
                  </span>
                  {universalResults.map((r, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setActiveModuleId(r.moduleId);
                        setUniversalQuery("");
                      }}
                      className="w-full p-2 hover:bg-zinc-50 dark:hover:bg-zinc-800 rounded-lg text-left transition flex flex-col gap-0.5 cursor-pointer border border-transparent hover:border-zinc-200"
                    >
                      <div className="flex justify-between items-center w-full">
                        <span className="text-xs font-black text-indigo-600 dark:text-yellow-400 uppercase tracking-tight">{r.title}</span>
                        <span className="text-[8px] font-black font-mono bg-zinc-100 dark:bg-zinc-800 border dark:border-zinc-700 text-zinc-500 px-1.5 py-0.5 rounded">
                          {r.section}
                        </span>
                      </div>
                      <span className="text-[10px] text-zinc-600 dark:text-zinc-400 font-medium truncate w-full">
                        {r.text}
                      </span>
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Theme Switcher Button */}
          <button
            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
            className="p-2.5 bg-zinc-100 dark:bg-zinc-800 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl hover:bg-zinc-200 dark:hover:bg-zinc-700 transition cursor-pointer text-zinc-900 dark:text-zinc-100 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
            title={theme === "light" ? "Switch to Dark Mode" : "Switch to Light Mode"}
          >
            {theme === "light" ? <Moon className="h-4.5 w-4.5" /> : <Sun className="h-4.5 w-4.5" />}
          </button>

          {/* Progress Widgets */}
          <div className="hidden lg:flex items-center gap-4">
            <div className="bg-emerald-50 dark:bg-emerald-950/20 border-2 border-zinc-900 dark:border-zinc-700 p-2 px-3.5 rounded-xl flex items-center gap-3">
              <div className="text-left">
                <span className="text-[8px] font-black font-mono text-emerald-800 dark:text-emerald-400 tracking-wider uppercase block">STUDY PATH</span>
                <span className="text-xs font-black font-mono text-zinc-900 dark:text-white block mt-0.5">{totalCompleted} / {modulesData.length} Done</span>
              </div>
              <div className="w-16 bg-zinc-200 dark:bg-zinc-800 h-2 rounded-full border border-zinc-900 dark:border-zinc-700 overflow-hidden">
                <div className="bg-emerald-500 h-full rounded-full transition-all duration-300" style={{ width: `${progressPercent}%` }}></div>
              </div>
            </div>

            <div className="bg-indigo-50 dark:bg-indigo-950/20 border-2 border-zinc-900 dark:border-zinc-700 p-2 px-3.5 rounded-xl">
              <span className="text-[8px] font-black font-mono text-indigo-800 dark:text-indigo-400 tracking-wider uppercase block font-bold">AVG ACCURACY</span>
              <span className="text-xs font-black font-mono text-zinc-900 dark:text-white block mt-0.5">{averageAccuracy}%</span>
            </div>

            <button 
              id="reset_progress_btn"
              onClick={handleResetProgress}
              className="p-2.5 bg-red-100 dark:bg-red-950/40 border-2 border-zinc-900 dark:border-zinc-700 rounded-xl hover:bg-red-200 transition text-zinc-900 dark:text-red-400 cursor-pointer shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
              title="Reset All Progress"
            >
              <RotateCcw className="h-4.5 w-4.5" />
            </button>
          </div>
        </div>

        {/* Mobile menu trigger */}
        <div className="flex items-center lg:hidden gap-3 self-end md:self-auto mt-2 md:mt-0">
          <button 
            onClick={handleResetProgress}
            className="p-2 py-1 px-3 border-2 border-zinc-900 rounded-lg bg-red-100 dark:bg-red-900/40 text-xs font-mono font-bold text-zinc-900 dark:text-red-400 hover:bg-red-200 cursor-pointer shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
          >
            Reset All
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 border-2 border-zinc-900 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-800 cursor-pointer text-zinc-900 dark:text-zinc-100 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </header>

      {/* Main Structural Grid */}
      <div className="flex-1 flex overflow-hidden gap-5">
        
        {/* Navigation Sidebar Drawer - Left column */}
        <aside className="w-80 p-4 shrink-0 flex flex-col justify-between hidden lg:flex bg-white dark:bg-zinc-900 border-2 border-zinc-900 dark:border-zinc-700 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] rounded-2xl">
          <div className="space-y-4 max-h-[calc(100vh-290px)] overflow-y-auto scrollbar-thin pr-1">
            {/* SDLC SECTION */}
            <div className="text-xs font-black tracking-widest uppercase text-zinc-500 dark:text-zinc-400 mb-1 font-mono">
              ★ SDLC PROCESS MODELS ({modulesData.filter(m => m.id !== 'dbms').length})
            </div>
            
            <nav className="space-y-2 mb-4">
              {modulesData.filter(m => m.id !== "dbms").map((m) => {
                const isActive = m.id === activeModuleId;
                const isCompleted = progress.completedModules.includes(m.id);
                return (
                  <button
                    key={m.id}
                    id={`side_nav_${m.id}`}
                    onClick={() => setActiveModuleId(m.id)}
                    className={`w-full p-2.5 rounded-xl border-2 text-left transition duration-150 cursor-pointer flex items-start gap-2.5 group relative ${
                      isActive 
                        ? "border-zinc-900 dark:border-zinc-700 bg-yellow-300 dark:bg-yellow-400 text-zinc-950 font-extrabold shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] translate-x-[-2px] translate-y-[-2px]" 
                        : "border-zinc-900 dark:border-zinc-750 bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-350 hover:border-zinc-900 hover:text-zinc-950 hover:bg-zinc-50 dark:hover:bg-zinc-800 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
                    }`}
                  >
                    <span className="text-base shrink-0 select-none">{m.emoji}</span>
                    <div className="flex-1 min-w-0">
                      <div className="font-sans font-black text-xs select-none uppercase tracking-tight text-zinc-950 dark:text-inherit">{m.title}</div>
                      <p className="text-[10px] text-zinc-500 dark:text-zinc-400 mt-1 select-none font-medium truncate">{m.shortDescription}</p>
                    </div>
                    {isCompleted && (
                      <span className="w-3.5 h-3.5 bg-emerald-500 border border-zinc-900 rounded-full flex items-center justify-center shrink-0 mt-0.5 shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]">
                        <span className="block w-1.5 h-1.5 bg-white rounded-full"></span>
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>

            {/* DBMS SECTION */}
            <div className="text-xs font-black tracking-widest uppercase text-indigo-600 dark:text-indigo-400 mb-1 font-mono">
              ★ DATABASE SYSTEMS (DBMS)
            </div>

            <nav className="space-y-2">
              {modulesData.filter(m => m.id === "dbms").map((m) => {
                const isActive = m.id === activeModuleId;
                const isCompleted = progress.completedModules.includes(m.id);
                return (
                  <button
                    key={m.id}
                    id={`side_nav_${m.id}`}
                    onClick={() => setActiveModuleId(m.id)}
                    className={`w-full p-2.5 rounded-xl border-2 text-left transition duration-150 cursor-pointer flex items-start gap-2.5 group relative ${
                      isActive 
                        ? "border-zinc-900 dark:border-zinc-700 bg-yellow-300 dark:bg-yellow-400 text-zinc-950 font-extrabold shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] translate-x-[-2px] translate-y-[-2px]" 
                        : "border-zinc-900 dark:border-zinc-750 bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-350 hover:border-zinc-900 hover:text-zinc-950 hover:bg-zinc-50 dark:hover:bg-zinc-800 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
                    }`}
                  >
                    <span className="text-base shrink-0 select-none">{m.emoji}</span>
                    <div className="flex-1 min-w-0">
                      <div className="font-sans font-black text-xs select-none uppercase tracking-tight text-zinc-950 dark:text-inherit">{m.title}</div>
                      <p className="text-[10px] text-zinc-500 dark:text-zinc-400 mt-1 select-none font-medium truncate">{m.shortDescription}</p>
                    </div>
                    {isCompleted && (
                      <span className="w-3.5 h-3.5 bg-emerald-500 border border-zinc-900 rounded-full flex items-center justify-center shrink-0 mt-0.5 shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]">
                        <span className="block w-1.5 h-1.5 bg-white rounded-full"></span>
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Student Profile Info Card */}
          <div className="bg-indigo-50 dark:bg-indigo-950/20 p-4 border-2 border-zinc-900 dark:border-zinc-700 rounded-2xl flex flex-col gap-3 relative overflow-hidden shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] mt-4">
            <div className="absolute -right-3 -bottom-3 bg-indigo-500/10 p-4 rounded-full">
              <Compass className="h-10 w-10 text-indigo-900/10" />
            </div>
            <div>
              <span className="text-[8px] font-mono tracking-widest text-indigo-700 dark:text-indigo-400 font-black block uppercase">STUDENT PROFILE</span>
              <span className="font-sans font-black text-xs text-zinc-900 dark:text-zinc-100 block mt-0.5 uppercase italic">SOFTWARE SYSTEMS STUDENT</span>
              <span className="text-[10px] text-zinc-500 dark:text-zinc-400 font-bold block mt-1">Syllabus Year 3 • ACEM SE Lab</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-zinc-900 dark:text-zinc-100 bg-white dark:bg-zinc-800 border border-zinc-900 dark:border-zinc-700 p-2 rounded-xl">
              <div>
                <span className="block text-zinc-400 font-bold uppercase tracking-widest text-[8px]">COMPLETED</span>
                <span className="text-zinc-900 dark:text-white font-extrabold">{totalCompleted} / {modulesData.length}</span>
              </div>
              <div>
                <span className="block text-zinc-400 font-bold uppercase tracking-widest text-[8px]">ACCURACY</span>
                <span className="text-zinc-900 dark:text-white font-extrabold">{averageAccuracy}%</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Mobile Dropdown drawer overlay */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div 
              initial={{ x: -280, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -280, opacity: 0 }}
              transition={{ type: "tween", duration: 0.15 }}
              className="fixed inset-y-0 left-0 bg-white dark:bg-zinc-900 z-50 p-6 border-r-2 border-zinc-900 dark:border-zinc-700 w-80 md:w-96 flex flex-col justify-between shadow-[6px_0px_0px_0px_rgba(0,0,0,1)] text-zinc-900 dark:text-zinc-100"
            >
              <div className="space-y-4 flex-1 flex flex-col overflow-hidden">
                <div className="flex justify-between items-center pb-2 border-b-2 border-zinc-900 dark:border-zinc-700 shrink-0">
                  <span className="text-xs font-black tracking-widest uppercase text-zinc-500 dark:text-zinc-400 font-mono">TOPICS TIMELINE ({modulesData.length})</span>
                  <button onClick={() => setMobileMenuOpen(false)} className="p-1.5 border-2 border-zinc-900 dark:border-zinc-700 rounded bg-zinc-900 text-white dark:bg-zinc-800 cursor-pointer"><X className="h-4 w-4" /></button>
                </div>
                <div className="overflow-y-auto max-h-[calc(100vh-270px)] scrollbar-thin pr-1 space-y-4">
                  {/* SDLC SECTION */}
                  <div className="text-[10px] font-black tracking-widest uppercase text-zinc-400 font-mono">
                    ★ SDLC PROCESS MODELS ({modulesData.filter(m => m.id !== 'dbms').length})
                  </div>
                  <nav className="space-y-2">
                    {modulesData.filter(m => m.id !== 'dbms').map((m) => {
                      const isActive = m.id === activeModuleId;
                      const isCompleted = progress.completedModules.includes(m.id);
                      return (
                        <button
                          key={m.id}
                          onClick={() => {
                            setActiveModuleId(m.id);
                            setMobileMenuOpen(false);
                          }}
                          className={`w-full p-2.5 rounded-xl border-2 text-left flex items-start gap-2.5 transition cursor-pointer ${
                            isActive 
                              ? "border-zinc-900 bg-yellow-300 dark:bg-yellow-400 text-zinc-950 font-extrabold shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]" 
                              : "border-zinc-900 dark:border-zinc-850 bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300"
                          }`}
                        >
                          <span className="text-base shrink-0">{m.emoji}</span>
                          <div>
                            <div className="font-sans font-black text-xs uppercase text-zinc-950 dark:text-inherit">{m.title}</div>
                            <p className="text-[10px] text-zinc-500 dark:text-zinc-450 mt-0.5 truncate">{m.shortDescription}</p>
                          </div>
                          {isCompleted && (
                            <span className="ml-auto w-2 h-2 bg-emerald-500 border border-zinc-900 rounded-full"></span>
                          )}
                        </button>
                      );
                    })}
                  </nav>

                  {/* DBMS SECTION */}
                  <div className="text-[10px] font-black tracking-widest uppercase text-indigo-600 dark:text-indigo-400 font-mono">
                    ★ DATABASE SYSTEMS (DBMS)
                  </div>
                  <nav className="space-y-2">
                    {modulesData.filter(m => m.id === 'dbms').map((m) => {
                      const isActive = m.id === activeModuleId;
                      const isCompleted = progress.completedModules.includes(m.id);
                      return (
                        <button
                          key={m.id}
                          onClick={() => {
                            setActiveModuleId(m.id);
                            setMobileMenuOpen(false);
                          }}
                          className={`w-full p-2.5 rounded-xl border-2 text-left flex items-start gap-2.5 transition cursor-pointer ${
                            isActive 
                              ? "border-zinc-900 bg-yellow-300 dark:bg-yellow-400 text-zinc-950 font-extrabold shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]" 
                              : "border-zinc-900 dark:border-zinc-850 bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300"
                          }`}
                        >
                          <span className="text-base shrink-0">{m.emoji}</span>
                          <div>
                            <div className="font-sans font-black text-xs uppercase text-zinc-950 dark:text-inherit">{m.title}</div>
                            <p className="text-[10px] text-zinc-500 dark:text-zinc-450 mt-0.5 truncate">{m.shortDescription}</p>
                          </div>
                          {isCompleted && (
                            <span className="ml-auto w-2 h-2 bg-emerald-500 border border-zinc-900 rounded-full"></span>
                          )}
                        </button>
                      );
                    })}
                  </nav>
                </div>
              </div>

              {/* Progress footer inside drawer */}
              <div className="border-t-2 border-zinc-900 dark:border-zinc-700 pt-4 space-y-4">
                <div className="grid grid-cols-2 gap-2 text-xs font-mono text-zinc-950 bg-indigo-50 dark:bg-indigo-950/25 border-2 border-zinc-900 dark:border-zinc-750 p-3 rounded-xl">
                  <div>
                    <span className="block text-zinc-400 text-[9px] font-bold">COMPLETED</span>
                    <span className="text-zinc-900 dark:text-zinc-200 font-extrabold">{totalCompleted} / {modulesData.length}</span>
                  </div>
                  <div>
                    <span className="block text-zinc-400 text-[9px] font-bold">QUIZ ACCURACY</span>
                    <span className="text-zinc-950 dark:text-zinc-200 font-extrabold">{averageAccuracy}%</span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
 
        {/* Right main column with theory and game displays */}
        <main className="flex-1 flex flex-col h-full overflow-hidden">
          <ModuleContainer 
            module={activeModule}
            progress={progress}
            onUpdateProgress={handleUpdateProgress}
            onNextModule={nextModule ? () => {
              setActiveModuleId(nextModule.id);
              document.getElementById("module_view_container")?.scrollIntoView({ behavior: "smooth" });
            } : undefined}
            nextModuleTitle={nextModule ? nextModule.title : undefined}
            onPrevModule={prevModule ? () => {
              setActiveModuleId(prevModule.id);
              document.getElementById("module_view_container")?.scrollIntoView({ behavior: "smooth" });
            } : undefined}
            prevModuleTitle={prevModule ? prevModule.title : undefined}
          />
        </main>
      </div>
    </div>
  );
}
