# Google Antigravity IDE Development Prompts

This document contains two high-quality, masterfully crafted prompts that you can copy and paste directly into Google Antigravity IDE. These prompts are optimized to build a complete, state-of-the-art interactive digital notes and simulation system.

---

## 📋 PROMPT 1: The App Development & Engine Builder
*Copy and run this prompt in your Antigravity IDE to bootstrap the full-stack interactive notebook application with Universal Search, Internal Search, Material Design theme, and the dual-search architecture.*

```markdown
Build a professional, responsive "Interactive Digital Notes & Simulator" application using React, TypeScript, and Tailwind CSS. The app should have a clean, polished, and distinctive Material Design / Bento Grid fusion aesthetic with elegant spacing, deep shadows, and precise typography.

### 🌟 Core Requirements & Features:
1. **Structural Scope**:
   - **Multi-Module Navigation**: Implement a sidebar layout for desktop and a slide-out drawer for mobile.
   - **Universal Search**: An top-level global search bar that fuzzy-searches across all modules, titles, and paragraphs.
   - **Internal Search**: A secondary search bar inside the active module's view to filter sub-topics, section headers, and specific terminology.
   - **Theme Engine**: A smooth theme-toggle button to switch between high-contrast light mode (soft off-whites, slate grays, Material-inspired vibrant accents) and elegant dark mode.
   - **Fully Responsive**: Optimized fluid breakpoints for Mobile (touch targets >= 44px), Tablet, and Desktop.

2. **Visual & Styling Guidelines**:
   - Adopt a highly polished Material Design aesthetic merged with Bento Grid layout principles: card elevations, clean borders, rounded corners (`rounded-2xl`), and elegant font pairings.
   - Use `lucide-react` for all icons. Do not create raw SVGs.
   - Use `motion` (imported from `motion/react`) for smooth page transitions and interactive hover effects.

3. **Data Architecture (Modular Structure)**:
   - Create `/src/types.ts` containing type definitions for `ModuleData`, `DetailedSection`, `QuizQuestion`, `RelatableExample`, and `StudentProgress`.
   - Create `/src/data/modulesData.ts` to hold all rich educational content. Include:
     - **Module 1**: DBMS Core (Topic 1: Database Management System introduction, components, files vs database systems).
     - **Module 2**: SDLC Process Models (Waterfall Model, Incremental Model, Prototype Model, V Model, Spiral Model, RAD Model, Agile Model).

4. **Interactive Sandbox Playgrounds**:
   - Each module must have an interactive sandbox inside `/src/components/InteractiveWidget.tsx` where students can modify slider inputs (e.g., timeline constraint, requirement stability, safety criticality, user involvement, budget) and immediately visualize which process model or architectural design matches their inputs.
   - Include a fully functional multiple-choice quiz system for each module with immediate scoring, visual correct/wrong feedback, and deep conceptual explanations.

Please structure the codebase modularly into `/src/types.ts`, `/src/data/modulesData.ts`, `/src/components/InteractiveWidget.tsx`, `/src/components/ModuleContainer.tsx`, and `/src/App.tsx` to ensure perfect code execution and maintainability.
```

---

## 📖 PROMPT 2: The Content & Academic Schema Generation
*Copy and run this prompt in a separate turn (or feed it to your content generator) to write the complete, comprehensive academic JSON data for DBMS Module 1 and Process Models Module 2 with extreme detail.*

```markdown
Write the TypeScript array content for `/src/data/modulesData.ts` containing two massive, highly-detailed educational modules: DBMS (Module 1) and Process Models (Module 2). The data must comply strictly with the `ModuleData` interface:

### 📐 Academic Syllabus Details to Generate:
1. **Module 1: Database Management Systems (DBMS)**
   - **Detailed Content**: Section 1: Introduction to Data vs. Information. Section 2: Why File Systems Fail (Concurrency anomalies, data redundancy, isolation problems). Section 3: DBMS Components (Query processor, storage manager, catalog, transactions).
   - **Analogies**: Filing cabinet drawers vs. central computerized digital warehouse.
   - **Interactive Simulator**: Let users input parameters (Data Size, Number of concurrent writers, Security Level, Complex Queries required) and see if a "Raw Text File" or "Relational DBMS" is appropriate with an efficiency graph.
   - **Quiz**: Two robust, challenging multiple-choice questions with full explanations.

2. **Module 2: Process Models (SDLC)**
   - **Detailed Content**:
     - **Waterfall Model**: Rigid, linear sequential stages. Best for fixed requirements.
     - **Incremental Model**: Phased software builds delivered sequentially.
     - **Prototype Model**: Visual mockups created first to refine requirements with users.
     - **V Model**: Verification and Validation aligning test plans with development stages.
     - **Spiral Model**: Risk-driven cycles with continuous prototyping and evaluation.
     - **Rapid Application Development (RAD)**: Speed-centric prototyping and quick iteration.
     - **Agile Model**: Iterative sprints, close user collaboration, high adaptability.
   - **Analogies**: Build a massive bridge (Waterfall) vs. build a modular city (Agile) vs. sketch a clay model of a car (Prototype).
   - **Interactive Simulator**: An interactive "Model Matcher Grid" where users can slide parameters:
     1. Requirements Certainty (Low to High)
     2. Delivery Timeline Speed (Slow to Rapid)
     3. Safety/Risk Level (Low to Human-life critical)
     4. Customer Involvement (None to Continuous)
     5. Budget Constraints (Low to Unlimited)
     As parameters slide, a dynamic bento-style card updates in real-time, showing which model matches best, complete with match percentage, description of why it fits, and potential pitfalls of that choice.
   - **Quiz**: Challenging scenarios mapping real-world project criteria to the correct model.

Ensure the output is valid TypeScript code, complete and production-ready without mock placeholders.
```
